package ae.daman.bcom.bpm.model;

import lombok.Data;

@Data
public class PoolsSummary {
    int assigned;
    int unAssigned;
    String value;
}
