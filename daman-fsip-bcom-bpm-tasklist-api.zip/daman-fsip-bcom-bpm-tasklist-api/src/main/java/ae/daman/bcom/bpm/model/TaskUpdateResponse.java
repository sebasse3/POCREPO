package ae.daman.bcom.bpm.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;


@Data
@XmlRootElement
public class TaskUpdateResponse{

    private String updateResponseStatus;

}
