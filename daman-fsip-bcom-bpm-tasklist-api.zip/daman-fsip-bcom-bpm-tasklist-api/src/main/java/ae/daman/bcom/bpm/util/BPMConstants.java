package ae.daman.bcom.bpm.util;

public class BPMConstants {
//Out of the box columns


    public static final String TITLE = "TITLE";
    public static final String TASKNUMBER = "TASKNUMBER";
    public static final String PRIORITY = "PRIORITY";
    public static final String ASSIGNEES = "ASSIGNEES";
    public static final String OUTCOME = "OUTCOME";
    public static final String STATE = "STATE";
    public static final String TASKID = "TASKID";
    public static final String ACQUIREDBY_BY = "ACQUIREDBY";
    public static final String ASSIGNED_DATE = "ASSIGNEDDATE";
    public static final String CREATED_DATE = "CREATEDDATE";
    public static final String UPDATED_BY = "UPDATEDBY";
    public static final String UPDATED_DATE = "UPDATEDDATE";
    public static final String CATEGORY = "CATEGORY";
    public static final String START_DATE = "STARTDATE";
    public static final String END_DATE = "ENDDATE";
    public static final String TASK_DISPLAY_URL = "TASKDISPLAYURL";
    public static final String ASSIGNED_BY = "ASSIGNEDBY";


    //Custom columns
    public static final String TASKTYPE = "TASKTYPE";
    public static final String STATUS = "STATUS";
    public static final String ROLE = "ROLE";
    public static final String ASSIGNED_TO ="ASSIGNEDTO";
    public static final String TASKDEFINATIONNAME = "TASKDEFINATIONNAME";
    public static final String ASSIGNED = "ASSIGNED";

    public static final String REFERENCE_NUMBER = "PROTECTEDTEXTATTRIBUTE2";
    public static final String POOL = "PROTECTEDTEXTATTRIBUTE3";
    public static final String REASON = "PROTECTEDTEXTATTRIBUTE4";
    public static final String TEAM = "PROTECTEDTEXTATTRIBUTE5";
    public static final String ACTIVITYTAT = "PROTECTEDNUMBERATTRIBUTE1";
    public static final String CUSTOMERTAT = "PROTECTEDNUMBERATTRIBUTE2";


    public static final String INFO_REQUESTED = "INFO_REQUESTED";
    public static final String INFO_SUBMITTED = "INFO_SUBMITTED";
    public static final String SEEK_APPROVAL = "SEEK_APPROVAL";
    public static final String SEEK_APPROVAL_SUBMITTED = "SEEK_APPROVAL_SUBMITTED";



    public static final String ASSIGN = "ASSIGN";
    public static final String REASSIGN = "REASSIGN";
    public static final String RELEASETOPOOL = "RELEASETOPOOL";



}
