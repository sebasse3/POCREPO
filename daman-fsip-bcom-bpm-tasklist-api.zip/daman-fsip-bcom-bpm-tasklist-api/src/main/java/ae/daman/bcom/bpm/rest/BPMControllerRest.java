package ae.daman.bcom.bpm.rest;


import ae.daman.bcom.bpm.model.*;
import ae.daman.bcom.bpm.rest.api.BPMController;
import ae.daman.bcom.bpm.util.JsonUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import oracle.bpel.services.workflow.StaleObjectException;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.tip.pc.services.identity.BPMIdentityException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Path("api")
@Component
@Slf4j
@Setter
public class BPMControllerRest {



    @Autowired
    private BPMController bpmController;

    @Path("getTasks")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTasks(TaskListRequest request){
        log.info("getTasks entry");
        log.debug("getTasks request : "+ JsonUtil.getJsonString(request));

        WorkflowTasks workflowTasks = new WorkflowTasks();
        try {
            workflowTasks = bpmController.getTasks(request);
        } catch (WorkflowException e) {
            log.info("getTasks error exit");
            log.debug("getTasks error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        } catch (IOException e) {
            log.info("getTasks error exit");
            log.debug("getTasks error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }
        log.debug("getTasks return : "+JsonUtil.getJsonString(workflowTasks));
        log.info("getTasks exit");
        return Response.status(Response.Status.OK).entity(workflowTasks).build();
    }

    @Path("updateTask")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response  updateTask(TaskUpdateRequest updateRequest){
        log.info("updateTask entry");
        log.debug("updateTask request : "+ JsonUtil.getJsonString(updateRequest));

        TaskUpdateResponse taskUpdateResponse = new TaskUpdateResponse();
        try {
              taskUpdateResponse = bpmController.updateTask(updateRequest);
        } catch (WorkflowException e) {
            log.info("updateTask error exit");
            log.debug("updateTask error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        } catch (StaleObjectException se) {
            log.info("updateTask error exit");
            log.debug("updateTask error : " + JsonUtil.getJsonString(se));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(se).build();
            }
            catch (IOException e) {
            log.info("updateTask error exit");
            log.debug("updateTask error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }
        log.debug("updateTask return : "+JsonUtil.getJsonString(taskUpdateResponse));
        log.info("updateTask exit");
        return Response.status(Response.Status.OK).entity(taskUpdateResponse).build();
    }

    @Path("reassignTask")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response  reassignTask(TaskReassignRequest reassignRequest){
        log.info("reassignTask entry");
        log.debug("reassignTask request : "+ JsonUtil.getJsonString(reassignRequest));

        TaskReassignResponse taskReassignResponse = new TaskReassignResponse();
        try {
            taskReassignResponse = bpmController.reassignTask(reassignRequest);
        } catch (WorkflowException e) {
            log.info("reassignTask error exit");
            log.debug("reassignTask error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        } catch (StaleObjectException se) {
            log.info("reassignTask error exit");
            log.debug("reassignTask error : " + JsonUtil.getJsonString(se));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(se).build();
        } catch (IOException e) {
            log.info("reassignTask error exit");
            log.debug("reassignTask error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }
        log.debug("reassignTask return : "+JsonUtil.getJsonString(taskReassignResponse));
        log.info("reassignTask exit");
        return Response.status(Response.Status.OK).entity(taskReassignResponse).build();
    }



    @Path("getPoolsList/{username}")
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response  getPoolsList(@PathParam("username") String username){
        log.info("taskPoolsList entry username :"+username );

        Map<String, PoolsSummary> taskPoolsList ;
        try {
            taskPoolsList  = bpmController.getPoolsList(username);
        } catch (WorkflowException e) {
            log.info("taskPoolsList error exit");
            log.debug("taskPoolsList error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }  catch (IOException e) {
            log.info("taskPoolsList error exit");
            log.debug("taskPoolsList error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }
        log.debug("taskPoolsList return : "+JsonUtil.getJsonString(taskPoolsList));
        log.info("taskPoolsList exit");
        return Response.status(Response.Status.OK).entity(taskPoolsList).build();
    }


    @Path("getPoolsTaskList/{username}")
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    public Response getPoolsTaskList(@PathParam("username") String username) throws WorkflowException, IOException {
        log.info("getPoolsTaskList entry");
        log.debug("getPoolsTaskList request : "+ username);

        WorkflowPoolTasks workflowTasks = new WorkflowPoolTasks();
//        Map<String, WorkflowPoolTasks> workflowTasks = new HashMap<>();
        try {
            workflowTasks = bpmController.getPoolsTaskList(username);
        } catch (WorkflowException e) {
            log.info("getPoolsTaskList error exit");
            log.debug("getPoolsTaskList error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        } catch (IOException e) {
            log.info("getPoolsTaskList error exit");
            log.debug("getPoolsTaskList error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }
        log.debug("getTasks return : "+JsonUtil.getJsonString(workflowTasks));
        log.info("getTasks exit");
        return Response.status(Response.Status.OK).entity(workflowTasks).build();
    }

    @Path("getUserForTaskAssignment/{poolName}")
    @GET
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    public Response getUserForTaskAssignment(@PathParam("poolName") String poolName) throws  BPMIdentityException  {
        log.info("getUserForTaskAssignment entry");
        log.debug("getUserForTaskAssignment poolName : "+ poolName);

       String userId = "";
        try {
            userId = bpmController.getUserForTaskAssignment(poolName);
        } catch (WorkflowException e) {
            log.info("getUserForTaskAssignment error exit");
            log.debug("getUserForTaskAssignment error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        } catch (IOException e) {
            log.info("getUserForTaskAssignment error exit");
            log.debug("getUserForTaskAssignment error : " + JsonUtil.getJsonString(e));
            return Response.status(Response.Status.SERVICE_UNAVAILABLE).entity(e).build();
        }
        log.debug("getUserForTaskAssignment return : "+JsonUtil.getJsonString(userId));
        log.info("getUserForTaskAssignment exit");
        return Response.status(Response.Status.OK).entity(userId).build();
    }

}


