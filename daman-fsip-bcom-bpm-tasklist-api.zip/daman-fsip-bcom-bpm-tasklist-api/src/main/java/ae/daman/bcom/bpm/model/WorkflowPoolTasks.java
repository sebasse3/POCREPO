package ae.daman.bcom.bpm.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@Data
@XmlRootElement
public class WorkflowPoolTasks {


    private List<WorkflowPoolsTask> tasks = new ArrayList<>();

    private int totalCount;

    public void addTask(WorkflowPoolsTask poolTask){
        this.tasks.add(poolTask);
    }

}