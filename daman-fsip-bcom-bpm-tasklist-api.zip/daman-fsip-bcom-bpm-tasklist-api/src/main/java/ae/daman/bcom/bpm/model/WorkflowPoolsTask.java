package ae.daman.bcom.bpm.model;

import lombok.Data;
import org.w3c.dom.Element;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Data
@XmlRootElement

public class WorkflowPoolsTask {

    private String taskId;
    private Integer taskNumber;
    private String referenceNumber;
    private Date startTime;
    private long customerTat;
    private String assignBefore;
    private String assignedBy;
    private String assignedTo;
    private String poolName;

}
