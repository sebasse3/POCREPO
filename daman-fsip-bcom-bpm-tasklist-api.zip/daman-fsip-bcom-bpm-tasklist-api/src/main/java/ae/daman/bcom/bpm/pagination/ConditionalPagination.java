package ae.daman.bcom.bpm.pagination;

import lombok.Data;

@Data
public class ConditionalPagination {

    private String orderBy;
    private Direction direction;
    private int page;
    private int size;
}
