package ae.daman.bcom.bpm.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@Data
@XmlRootElement
public class WorkflowTasks {

    private List<WorkflowTask> tasks = new ArrayList<>();

    private int totalCount;

    public void addTask(WorkflowTask task){
        this.tasks.add(task);
    }

}
