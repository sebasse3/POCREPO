package ae.daman.bcom.bpm.model;

import java.util.Date;

public class WorkflowTaskDummy {

    public WorkflowTasks getAwaitingClarificationTasks(){
        WorkflowTasks tasks = new WorkflowTasks();

        WorkflowTask task = new WorkflowTask();
        task.setActivityTat(345676);
        task.setAssignedBy("SYSTEM");
        task.setCustomerTat(214234);
        task.setPoolName("ADNOC");
        task.setTaskStatus("Draft");
        task.setPriority("2");
        task.setReferenceNumber("ENRCC1234");
        task.setStartTime(new Date());
        task.setTaskType("Enrollment-Clarification");
        task.setReason("Requested for Clarification");
        task.setAssignedTo("Customer");

        WorkflowTask task1 = new WorkflowTask();
        task1.setActivityTat(24243);
        task1.setAssignedBy("SYSTEM");
        task1.setCustomerTat(43242);
        task1.setPoolName("ADNOC");
        task1.setTaskStatus("Draft");
        task1.setPriority("2");
        task1.setReferenceNumber("ENRCC1234");
        task1.setStartTime(new Date());
        task1.setTaskType("Enrollment-Clarification");
        task.setReason("Requested for Clarification");
        task.setAssignedTo("Customer");

        tasks.addTask(task);
        tasks.addTask(task1);
        tasks.setTotalCount(100);
        return tasks;
    }

    public WorkflowTasks getPendingApprovalTasks(){
        WorkflowTasks tasks = new WorkflowTasks();

        WorkflowTask task = new WorkflowTask();
        task.setActivityTat(2222);
        task.setAssignedBy("SYSTEM");
        task.setCustomerTat(3444);
        task.setPoolName("ADNOC");
        task.setTaskStatus("Draft");
        task.setPriority("2");
        task.setReferenceNumber("ENRCC1234");
        task.setStartTime(new Date());
        task.setTaskType("Enrollment-Clarification");
        task.setReason("Raised for Approval");
        task.setAssignedTo("Hanif Mohd.");

        WorkflowTask task1 = new WorkflowTask();
        task1.setActivityTat(4444);
        task1.setAssignedBy("SYSTEM");
        task1.setCustomerTat(234234);
        task1.setPoolName("ADNOC");
        task1.setTaskStatus("Draft");
        task1.setPriority("2");
        task1.setReferenceNumber("ENRCC1234");
        task1.setStartTime(new Date());
        task1.setTaskType("Enrollment-Clarification");
        task.setReason("Raised for Approval");
        task.setAssignedTo("Hanif Mohd.");

        tasks.addTask(task);
        tasks.addTask(task1);
        tasks.setTotalCount(100);
        return tasks;
    }

    public WorkflowTasks getTodoTasks(){
        WorkflowTasks tasks = new WorkflowTasks();

        WorkflowTask task = new WorkflowTask();
        task.setActivityTat(23423);
        task.setAssignedBy("SYSTEM");
        task.setCustomerTat(234234);
        task.setPoolName("ADNOC");
        task.setTaskStatus("Draft");
        task.setPriority("2");
        task.setReferenceNumber("ENRCC1234");
        task.setStartTime(new Date());
        task.setTaskType("Enrollment-Clarification");

        WorkflowTask task1 = new WorkflowTask();
        task1.setActivityTat(23423);
        task1.setAssignedBy("SYSTEM");
        task1.setCustomerTat(2342);
        task1.setPoolName("ADNOC");
        task1.setTaskStatus("Draft");
        task1.setPriority("2");
        task1.setReferenceNumber("ENRCC1234");
        task1.setStartTime(new Date());
        task1.setTaskType("Enrollment-Clarification");

        tasks.addTask(task);
        tasks.addTask(task1);
        tasks.setTotalCount(100);
        return tasks;
    }

}
