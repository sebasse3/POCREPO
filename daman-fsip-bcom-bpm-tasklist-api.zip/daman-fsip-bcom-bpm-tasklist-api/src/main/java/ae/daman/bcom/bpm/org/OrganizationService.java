package ae.daman.bcom.bpm.org;

import org.springframework.stereotype.Component;

@Component
public class OrganizationService {
}
