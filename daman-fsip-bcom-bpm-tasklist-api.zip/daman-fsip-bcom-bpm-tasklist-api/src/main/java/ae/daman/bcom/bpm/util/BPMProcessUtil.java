package ae.daman.bcom.bpm.util;

import ae.daman.bcom.bpm.config.BPMProperties;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import oracle.bpel.services.bpm.common.IBPMContext;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.bpel.services.workflow.client.IWorkflowServiceClient;
import oracle.bpel.services.workflow.client.IWorkflowServiceClientConstants;
import oracle.bpel.services.workflow.client.WorkflowServiceClientFactory;
import oracle.bpel.services.workflow.query.ITaskQueryService;
import oracle.bpel.services.workflow.report.ITaskReportService;
import oracle.bpm.client.BPMServiceClientFactory;
import oracle.bpm.services.client.IBPMServiceClient;
import oracle.bpm.services.organization.IBPMOrganizationService;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
@Setter
public final class BPMProcessUtil {

    private static BPMProperties bpmProperties;

    private static BPMServiceClientFactory clientFactory;
    private IBPMServiceClient bpmServiceClient_;
    private IWorkflowServiceClient wfServiceClient_;
    private IBPMOrganizationService bpmOrganizationService_;

    private static String lock = "BPMProcessUtil";
/*
    public String getApplicationProperties(){
        return("BPM_HOST: "+ bpmProperties.getHost()+ " BPM_PORT: "+ bpmProperties.getPort()+ " INITIAL CONTEXT : "+bpmProperties.getInitialContextFactory());
    }
*/
    public static void setBPMProperties( BPMProperties bpmProperties){
        BPMProcessUtil.bpmProperties = bpmProperties;
    }
    public static BPMServiceClientFactory getServiceClientFactory() throws IOException {

        log.debug("inside getServiceClientFactory()");
        synchronized (lock) {
            if (clientFactory == null) {

                log.debug("Creating BPMServiceClientFactory");

                Map<IWorkflowServiceClientConstants.CONNECTION_PROPERTY, String> properties =
                        new HashMap<IWorkflowServiceClientConstants.CONNECTION_PROPERTY, String>();

                properties.put(IWorkflowServiceClientConstants.CONNECTION_PROPERTY.CLIENT_TYPE,
                        WorkflowServiceClientFactory.REMOTE_CLIENT);
                properties.put(IWorkflowServiceClientConstants.CONNECTION_PROPERTY.EJB_PROVIDER_URL,
                        "t3://" + bpmProperties.getHost() + ":" + bpmProperties.getPort());
                properties.put(IWorkflowServiceClientConstants.CONNECTION_PROPERTY.EJB_INITIAL_CONTEXT_FACTORY,
                        bpmProperties.getInitialContextFactory());

                clientFactory = BPMServiceClientFactory.getInstance(properties, null, null);
            }
        }
        log.debug("BPMServiceClientFactory is " + clientFactory);
        return clientFactory;
    }

    /**
     * IBPMContext is a subclass of workflow context so this can be used everywhere
     * This method provides the context for admin user.
     * @return IBPMContext
     * @throws WorkflowException
     */
    public static IBPMContext getContext() throws WorkflowException, IOException {
        char[] passwordCharArray = null;
        if (bpmProperties.getAdminPassword() != null) {
            passwordCharArray = bpmProperties.getAdminPassword().toCharArray();
        }
        IBPMContext ctx =
                (IBPMContext) getTaskQueryService().authenticate(bpmProperties.getAdminUser(), passwordCharArray, null);
        return ctx;
    }

    /**
     * IBPMContext is a subclass of workflow context so this can be used everywhere
     * This method provides the context for users
     * @return IBPMContext
     * @throws WorkflowException
     */
    public static IBPMContext getContext(String username) throws WorkflowException, IOException {
        IBPMContext ctx =
                (IBPMContext) getTaskQueryService().authenticateOnBehalfOf(getContext(), username);
        return ctx;
    }

    public static ITaskQueryService getTaskQueryService() throws IOException {
        IWorkflowServiceClient client = getServiceClientFactory().getWorkflowServiceClient();

        return client.getTaskQueryService();
    }
    public static ITaskReportService getTaskReportService() throws IOException {
        IWorkflowServiceClient client = getServiceClientFactory().getWorkflowServiceClient();

        return client.getTaskReportService();
    }
//added
    public static IWorkflowServiceClient getWorkflowServiceClient() throws IOException {
        IWorkflowServiceClient client = getServiceClientFactory().getWorkflowServiceClient();
        return client;
    }

}

