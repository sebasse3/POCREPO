package ae.daman.bcom.bpm.rest.api;

import ae.daman.bcom.bpm.model.*;
import ae.daman.bcom.bpm.task.TaskService;
import ae.daman.bcom.bpm.user.UserService;
import oracle.bpel.services.workflow.StaleObjectException;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.tip.pc.services.identity.BPMIdentityException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Map;

@Component
public class BPMControllerImpl implements BPMController {

    @Autowired
    private TaskService taskService;

    @Autowired
    private UserService userService;

    @Override
    public WorkflowTasks getTasks(TaskListRequest request) throws WorkflowException, IOException {
        return taskService.getTasks(request);
    }

    @Override
    public Map<String, PoolsSummary> getPoolsList(String username)throws WorkflowException, IOException{
        return taskService.getPoolsList(username);
    }

    @Override
    public TaskUpdateResponse updateTask(TaskUpdateRequest updateRequest) throws WorkflowException, StaleObjectException,IOException {
        return taskService.updateTask(updateRequest);
    }
    @Override
    public TaskReassignResponse reassignTask(TaskReassignRequest reassignRequestRequest) throws WorkflowException, StaleObjectException,IOException {
        return userService.reassignTask(reassignRequestRequest);
    }
    @Override
    public WorkflowPoolTasks getPoolsTaskList(String username) throws WorkflowException, IOException {
        return taskService.getPoolsTaskList(username);
    }

//    @Override
//    public Map<String, WorkflowPoolTasks> getPoolsTaskList(String username) throws WorkflowException, IOException {
//        return taskService.getPoolsTaskList(username);
//    }

    @Override
    public  String getUserForTaskAssignment(String poolName) throws  BPMIdentityException  {
        return userService.getUserForTaskAssignment(poolName);
    }

}
