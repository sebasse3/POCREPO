package ae.daman.bcom.bpm.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlRootElement
public class TaskUpdateRequest {
    private String username;
    private int taskNumber;
    private String taskId;
    private String taskStatus;
    private String outCome;
    private String appprover;
}
