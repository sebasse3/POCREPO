package ae.daman.bcom.bpm.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;


@Data
@XmlRootElement
public class TaskReassignRequest {
    private String username;
    private int taskNumber;
    private String taskId;
    private String assignmentType;
}