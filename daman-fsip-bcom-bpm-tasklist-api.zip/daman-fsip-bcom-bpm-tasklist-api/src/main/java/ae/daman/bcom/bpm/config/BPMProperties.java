package ae.daman.bcom.bpm.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "bpm")
@Data
public class BPMProperties {
    private String host;
    private String port;
    private String initialContextFactory;
    private String adminUser;
    private String adminPassword;
}
