package ae.daman.bcom.bpm.model;

public enum TaskStatusType {

    ASSIGNED("ASSIGNED"), PENDING_CLARIFICAITON("PENDING_CLARIFICAITON"), PENDING_APPROVAL("PENDING_APPROVAL");
    private final String taskStatusType;

    private TaskStatusType(String taskStatusType) {
        this.taskStatusType = taskStatusType;
    }

    public String getTaskStatusType() {
        return this.taskStatusType;
    }
}
