package ae.daman.bcom.bpm.model;

import ae.daman.bcom.bpm.pagination.ConditionalPagination;
import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlRootElement
public class TaskListRequest {
    private String username;
    private ConditionalPagination pagination;
    private TaskStatusType taskStatusType;
}


