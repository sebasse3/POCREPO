package ae.daman.bcom.bpm.model;

import lombok.Data;
import org.w3c.dom.Element;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Data
@XmlRootElement
public class WorkflowTask {

    private String taskId;
    private Integer taskNumber;
    private String referenceNumber;
    private Date startTime;
    private String taskType;
    private long customerTat;
    private long activityTat;
    private String poolName;
    private String taskStatus;
    private String assignedBy;

    private String team;
    private String reason;
    private String assignedTo;
    private String priority;
//    private Element payload;
//    private String assignees;





}
