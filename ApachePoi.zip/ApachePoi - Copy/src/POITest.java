import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xwpf.usermodel.XWPFComment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.usermodel.Range;

public class POITest {

	public static void main(String[] args) {
	    File file = null;
	    FileInputStream fis = null;
	    try {
	        file = new File("C:/seb/DRS.xls");
	        fis = new FileInputStream(file);
	        if (file.getPath().toLowerCase().indexOf(".docx")>-1){
	        	XWPFDocument document = null;
	    	    XWPFComment[] commentRange = null;
		        document = new XWPFDocument(fis);
		        commentRange = document.getComments();
		        int numComments = commentRange.length;
		        for (int i = 0; i < numComments; i++) {
		            String comments = commentRange[i].getText();
		            comments = comments.replaceAll("\\cM?\r?\n", "").trim();
		            if (!comments.equals("")) {
		                System.out.println("comment :-  " + comments);
		            }
		        }
		    }
	        else if (file.getPath().toLowerCase().indexOf(".doc")>-1){
	    	    HWPFDocument document = null;
	    	    Range commentRange = null;
		        document = new HWPFDocument(fis);
		        commentRange = document.getCommentsRange();
		        int numComments = commentRange.numParagraphs();
		        for (int i = 0; i < numComments; i++) {
		            String comments = commentRange.getParagraph(i).text();
		            
		            comments = comments.replaceAll("\\cM?\r?\n", "").trim();
		            if (!comments.equals("")) {
		                System.out.println("comment :-  " + comments);
		            }
		        }
		    }
	        else if (file.getPath().toLowerCase().indexOf(".xls")>-1){
		        Workbook wb = WorkbookFactory.create(fis);
		        Sheet sheet = wb.getSheetAt(0);
		        for (int row = 0; row <= sheet.getLastRowNum(); row++)
		        {
		          Row sheetRow = sheet.getRow(row);
		          for (int col = 0; col < sheetRow.getLastCellNum(); col++)
		          if (sheetRow != null && sheetRow.getCell(col)!=null)
		          {
		        	  //System.out.println("row:col::"+row+":"+col);
		              Cell cell = sheetRow.getCell(col);
		              if(cell.getCellComment()!=null)
		            	  System.out.println(cell.getCellComment().getString());
		          }
		        }
		    }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}
