import java.io.*;
import java.util.List;

import org.apache.poi.hslf.usermodel.HSLFComment;
import org.apache.poi.hslf.usermodel.HSLFSlide;
import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.usermodel.Range;
//import org.apache.poi.POIXMLProperties.*;
import org.apache.poi.ooxml.POIXMLProperties.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xslf.usermodel.*;
import org.apache.poi.xwpf.usermodel.XWPFComment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

public class HelloPoi {

	public static void main(String[] args) {

		try {

			String fileName = "C:/seb/DRS.xlsx";
			FileInputStream inputStream = new FileInputStream(fileName);

			if (fileName.toLowerCase().indexOf(".docx") > -1) {
				XWPFDocument document = null;
				XWPFComment[] commentRange = null;
				document = new XWPFDocument(inputStream);
				commentRange = document.getComments();
				int numComments = commentRange.length;
				for (int i = 0; i < numComments; i++) {
					String comments = commentRange[i].getText();
					comments = comments.replaceAll("\\cM?\r?\n", "").trim();
					if (!comments.equals("")) {
						System.out.println("comment :-  " + comments);
					}
				}
			} else if (fileName.toLowerCase().indexOf(".doc") > -1) {
				HWPFDocument document = null;
				Range commentRange = null;
				document = new HWPFDocument(inputStream);
				commentRange = document.getCommentsRange();
				int numComments = commentRange.numParagraphs();
				for (int i = 0; i < numComments; i++) {
					String comments = commentRange.getParagraph(i).text();

					comments = comments.replaceAll("\\cM?\r?\n", "").trim();
					if (!comments.equals("")) {
						System.out.println("comment :-  " + comments);
					}
				}
			} else if (fileName.toLowerCase().indexOf(".xls") > -1) {
				Workbook wb = WorkbookFactory.create(inputStream);
				Sheet sheet = wb.getSheetAt(0);
				for (int row = 0; row <= sheet.getLastRowNum(); row++) {
					Row sheetRow = sheet.getRow(row);
					for (int col = 0; col < sheetRow.getLastCellNum(); col++)
						if (sheetRow != null && sheetRow.getCell(col) != null) {
							// System.out.println("row:col::"+row+":"+col);
							Cell cell = sheetRow.getCell(col);
							if (cell.getCellComment() != null)
								System.out.println(cell.getCellComment().getString());
						}
				}
			}else if (fileName.toLowerCase().indexOf(".pptx") > -1) {
				XMLSlideShow ppt = new XMLSlideShow(inputStream);
				readPPTX(ppt);
			}else if (fileName.toLowerCase().indexOf(".ppt") > -1){
				HSLFSlideShow ppt = new HSLFSlideShow(inputStream);
				readPPT(ppt);
			}
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
	}

	public static void readPPTX(XMLSlideShow ppt) {
		CoreProperties props = ppt.getProperties().getCoreProperties();

		String title = props.getTitle();
		System.out.println("Title: " + title);

		for (XSLFSlide slide : ppt.getSlides()) {
			System.out.println("Starting PPTX slide...");
			// XSLFShape[] shapes = slide.getShapes();

			/*
			 * List<XSLFShape> shapes = slide.getShapes(); for (XSLFShape shape:
			 * shapes) { if (shape instanceof XSLFTextShape) { XSLFTextShape
			 * textShape = (XSLFTextShape)shape; String text =
			 * textShape.getText(); System.out.println("Text: " + text); } }
			 */

			List<XSLFComment> comments = slide.getComments();
			for (XSLFComment comment : comments) {
				if (comment instanceof XSLFComment) {
					XSLFComment textComment = (XSLFComment) comment;
					String commentText = textComment.getText();
					System.out.println("Comment: " + commentText);
				}
			}
		}
	}

	public static void readPPT(HSLFSlideShow ppt) {

		for (HSLFSlide slide : ppt.getSlides()) {
			System.out.println("Starting PPT slide...");

			List<HSLFComment> comments = slide.getComments();
			for (HSLFComment comment : comments) {
				if (comment instanceof HSLFComment) {
					HSLFComment textComment = (HSLFComment) comment;
					String commentText = textComment.getText();
					System.out.println("Comment: " + commentText);
				}
			}
		}
	}

}