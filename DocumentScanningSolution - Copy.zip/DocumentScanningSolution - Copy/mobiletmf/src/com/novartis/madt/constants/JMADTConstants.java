package com.novartis.madt.constants;

public class JMADTConstants {
	public static String BASE_PATH = "/home/sys_motion_madt/mobileTMF/";
	public static String ASPOSE_LICENCE = "Aspose.Pdf.lic";
}
