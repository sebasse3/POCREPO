package com.novartis.madt.batch;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.novartis.madt.model.ListItem;
import com.novartis.madt.repository.DocumentRepository;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.constants.JMADTConstants;
import com.novartis.madt.exception.DocumentScaningException;


/**
 * This Class is used to start the document conversion
 * @author medidsu1
 *
 */
public class MADTDocumentConversionBatchJob implements Runnable
{
	static Logger logger = Logger.getLogger(MADTDocumentConversionBatchJob.class.getSimpleName());
	String wctx = null;
	String adfsToken = null;
	String t = null;
	String cookies = null;
	String formDgToken = null;
	MADTSharePointServiceImpl sharepointDatafetch =  new MADTSharePointServiceImpl();;
	SharePointDocumntRepositoryImpl sharepointDocumentRepository = null;
	ResourceBundle messages = null;
	List<ListItem> listItems=null;
	Map<String,String> map=null;
	/**
	 * empty constructor
	 */
	public MADTDocumentConversionBatchJob(){
		super();
	}
	
	/**
	 * @param listItems
	 * @param messages
	 * @param map
	 */
	public MADTDocumentConversionBatchJob(List<ListItem> listItems,ResourceBundle messages,Map map){
		this.messages=messages;
		this.listItems=listItems;
		this.map=map;
	
	}
	//Load loggerfile and aspose licence while starting itself
	static {
		 
		loadLogerFile();
		}
	
	
	public static void main(String[] args) {
	
		MADTDocumentConversionBatchJob madt = new MADTDocumentConversionBatchJob();
		try {
		
			madt.process();

		} catch (Exception e) {
			
			logger.log(Level.SEVERE, "error while document scanning ", e.getStackTrace());
		}
	}

	

	/**This method is used to process the document conversion
	 * @throws Exception
	 */
	public void process() throws Exception {
		FileInputStream fis = null;
		try {
			String currentDir = System.getProperty("config");
			fis = new FileInputStream(currentDir);
			messages = new PropertyResourceBundle(fis);
			sharepointDatafetch = new MADTSharePointServiceImpl();
			sharepointDatafetch.setMessage(messages);
			sharepointDocumentRepository = new SharePointDocumntRepositoryImpl();
			sharepointDocumentRepository.setMessage(messages);
			map = sharepointDatafetch.setUp();
			ExecutorService ex = Executors.newFixedThreadPool(Integer.parseInt(messages.getString("threadCount")));
			List<String> list = sharepointDocumentRepository.getPendingList(map);
			logger.info("document list===>"+list.size());
			logger.info("thread count==>"+messages.getString("threadCount"));
			for (String string : list) {
				if (null != string && !"".equals(string)) {
					int id = Integer.parseInt(string);
					listItems = sharepointDocumentRepository.documentList(map, id);
					if (null != listItems && listItems.size() > 0) {
						ex.execute(new MADTDocumentConversionBatchJob(listItems, messages, map));						
					}
				}
			}
			
			ex.shutdown();
			
			while(!ex.isTerminated()) {
				logger.info("Please wait Process is still running ");
				Thread.sleep(60000);				
			}
			
			logger.info("Finished All threads");
			
		} catch (DocumentScaningException e) {
			logger.log(Level.SEVERE, "error while processing list ", e);
			throw new DocumentScaningException("error while processing list", e);

		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while processing list ", e);
			throw new Exception("error while processing list ", e);
		} finally {
			if (null != fis) {
				fis.close();
			}
			
		}

	}
	
	@Override
	public void run() {
		
		String fileName = null;
		String filePath = null;
		String subFilePath = null;
		String createdDt = null;
		try {
			for (ListItem listItem : listItems) {

				fileName = listItem.getFileName();
				filePath = listItem.getFilePath();
				createdDt=listItem.getCreationDt();
				//checking null condition and empty for fileName  and replace space with special character
				if (null != fileName && !"".equals(fileName)) {
					fileName = fileName.trim();
					fileName = URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
				}
				//checking null condition and empty for filePath and replace space with special character
				if (null != filePath && !"".equals(filePath)) {
					subFilePath = substringBeforeLast(filePath, "/");
					filePath = URLEncoder.encode(filePath, "UTF-8").replaceAll("\\+", "%20");
					subFilePath = URLEncoder.encode(subFilePath, "UTF-8").replaceAll("\\+", "%20");

				}
				//Release #2 Adding createdDt as document Custom property
				if (null != createdDt && !"".equals(createdDt)) {
					createdDt = createdDt.trim();
				}
				//Release #2 Adding createdDt as document Custom property
				logger.info("createdDt-->"+createdDt);
				if (null != fileName && !"".equals(fileName)&& null != filePath && !"".equals(filePath)) {
					 sharepointDatafetch.processDoucment(createdDt,subFilePath, fileName,messages,1);
				}

			}

		} catch (DocumentScaningException e) {
			logger.log(Level.SEVERE, "error while processing Doucment", e);
			
		}
		catch (Exception e) {
			logger.log(Level.SEVERE, "error while processing Doucment", e);

		}
	}

	/**
	 * This method is used to split spring as filepath and fileName
	 * @param str
	 * @param separator
	 * @return
	 */
	public String substringBeforeLast(String str, String separator) {
		int pos = str.lastIndexOf(separator);
		if (pos == -1) {
			return str;
		}
		return str.substring(0, pos);
	}
	/**
	 * This method is used to load log configuration file
	 */
	public static void loadLogerFile()
		 {
				InputStream is = null;
				try {
					is = new FileInputStream(
							JMADTConstants.BASE_PATH+"javalogging.properties");
					LogManager.getLogManager().readConfiguration(is);
				}
		
				catch (Exception e) {
					if (null != is) {
						try {
							is.close();
						} catch (IOException e1) {
		
						}
					}
				}
			}
	
}
