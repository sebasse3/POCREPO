package com.novartis.madt.batch;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.model.MADTDSStudy;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.util.JMADTUtil;
import com.novartis.madt.util.PasswordEncUtil;

/**
 * This is batch utility to fetch the folders data from Impact site using API
 * gateway, create the folders and providing permissions in SharePoint site
 * using SharePoint Rest API
 * 
 * @author SANKUSR2
 *
 */
public class MADTFolderCreationBatchJob {

	CredentialsProvider credsProvider = new BasicCredentialsProvider();
	SSLContextBuilder sslcontext = new SSLContextBuilder();
	CloseableHttpClient httpClient = HttpClients.custom().setDefaultCredentialsProvider(credsProvider).build();
	static Logger logger = Logger.getLogger(MADTFolderCreationBatchJob.class.getSimpleName());
	String wctx = null;
	String adfsToken = null;
	String t = null;
	String cookies = null;
	String formDgToken = null;
	MADTSharePointServiceImpl sharepointDatafetch = null;
	SharePointDocumntRepositoryImpl sharepointDocumentRepository = null;
	ResourceBundle messages = null;
	Map<String, String> map = null;
	static {
		JMADTUtil.loadLogerFile();
	}

	public MADTFolderCreationBatchJob() {
	}

	MADTFolderCreationBatchJob(ResourceBundle messages) {
		this.messages = messages;
	}

	/**
	 * This is the entry point for batch
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		MADTFolderCreationBatchJob madt = new MADTFolderCreationBatchJob();
		String fileStr = null;
		String startDate;
		String endDate;
		try {
			String qryDate = "";
			String batchType = null;
			if (args.length > 0 && ("Manual").equalsIgnoreCase(args[0])) {
				logger.info("inside if");
				if (args.length > 1 )  // Release #2 changes implemented
					batchType = args[1]; // Release #2 changes implemented
				@SuppressWarnings("resource")
				Scanner scanner = new Scanner(System.in);
				System.out.println("Enter the start Date in yyyy-MM-dd");
				String inputDt = scanner.next();
				boolean flagStr = JMADTUtil.validateDate(inputDt);
				int count = 0;
				while (!flagStr) {
					System.out.println("Enter the Date in yyyy-MM-dd format only");
					count++;
					inputDt = scanner.next();
					flagStr = JMADTUtil.validateDate(inputDt);
					if (count > 1) {
						System.out.println(
								"Invaid Date format Entered, System exiting, Please try again with Valid Date Format");
						System.exit(1);
					}
				}
				System.out.println("Enter the End Date in yyyy-MM-dd Format");
				String inputendDt = scanner.next();
				boolean flagendDtStr = JMADTUtil.validateDate(inputendDt);
				int countend = 0;
				while (!flagendDtStr) {
					System.out.println("Enter the End Date in yyyy-MM-dd format only");
					countend++;
					inputendDt = scanner.next();
					flagStr = JMADTUtil.validateDate(inputendDt);
					if (countend > 1) {
						System.out.println(
								"Invaid Date format Entered, System exiting, Please try again with Valid Date Format");
						System.exit(1);
					}
				}
				// Release #2 changes implemented
				if (null!=batchType && batchType.equalsIgnoreCase("COC_History")) {
					System.out.println("Please Note: Dates Enterd by you are considered 3 months old of entered date range for Completed or Cancelled Case");
					inputDt = JMADTUtil.convertToDateMinus3(inputDt);
					inputendDt = JMADTUtil.convertToDateMinus3(inputendDt);

				}
				logger.info("input Dt===>" + inputDt);
				logger.info("input end Dt===>" + inputendDt);
				startDate = inputDt + "T00:00:00";
				endDate = inputendDt + "T23:59:59";

				if (JMADTUtil.validateDate(startDate, endDate)) {
					System.out.println("Please enter Valid End Date");
					System.exit(1);
				}

				madt.excuteProcess(fileStr, batchType, startDate, endDate);
				// Defect#2 Added condition for reading folder data from file and process.
			} else if (args.length > 0 && ("File").equalsIgnoreCase(args[0])) {
				logger.info("inside else if file type");
				fileStr = null;
				startDate = null;
				endDate = null;
				fileStr = args[1];
				logger.info("inside main () - else if - fileStr===>" + fileStr);
				logger.info("inside main () else if - batchType-->" + batchType);
				madt.excuteProcess(fileStr, batchType, startDate, endDate);
			}

			else {

				logger.info("main():: inside else daily batch arguements length-->" + args.length);
				if (args.length > 0)
					batchType = args[0];
				// Release #2 changes implemented.
				if(null != batchType && batchType.equalsIgnoreCase("COC_Daily")) {
					qryDate = JMADTUtil.convertToDateMinus3(JMADTUtil.convertStringToDate(new Date()));
					logger.info("inside if COC_Daily : qryDate: "+ qryDate);
				}
				else {
					qryDate = JMADTUtil.convertStringToDate(new Date());
					logger.info("inside else Daily batch : qryDate: "+ qryDate);
				}
				startDate = qryDate + "T00:00:00";
				endDate = qryDate + "T23:59:59";
				logger.info("inside main () else batchType-->" + batchType);
				madt.excuteProcess(fileStr, batchType, startDate, endDate);
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while Folder Creation and providing permission", e.getStackTrace());

		} finally {
			System.exit(1);
		}
	}

	/**
	 * This method is used to connect the SharePoint and create folders and provide
	 * access to authorized CRA
	 * 
	 * @param documentFolder
	 *            folder name to be created
	 * @param user
	 *            CRA to be given access
	 * @param studyObj
	 *            MADTStudy Object holding folder data
	 * @param bw
	 *            file writer for writing error data to file.
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public String processFolder(String documentFolder, String user, MADTDSStudy studyObj, BufferedWriter bw,
			boolean coc_flag,boolean removeFlag) throws Exception {
		logger.info("start  of the method");
		String result = "success";
		try {
			logger.info("messages:::::" + messages);
			map = sharepointDatafetch.setUp(documentFolder, studyObj, bw);
			logger.info("coc_flag:::::" + coc_flag);
			String permission = messages.getString("permission");
			// Release 2 - changes implemented
			if (coc_flag) {
				String itemId = sharepointDocumentRepository.getID(map, documentFolder);
				String principalId = sharepointDocumentRepository.principalId(map, documentFolder, user);
				sharepointDocumentRepository.removePermission(map, itemId, principalId, documentFolder,studyObj,bw);
				sharepointDocumentRepository.recreatePermission(map, itemId, principalId, documentFolder, permission,studyObj,bw);
			} else { 
				//Added condition for removing the access to CRA as ssp end date is today or older.
				if(removeFlag){ 
					logger.info("processFolder::Inside removeFlag:: "+removeFlag);
					//String itemId = sharepointDocumentRepository.getID(map, documentFolder);
					//String principalId = sharepointDocumentRepository.principalId(map, documentFolder, user);
					//sharepointDocumentRepository.createFolderPermission(map, principalId,itemId,documentFolder, permission,removeFlag,studyObj,bw);
					
					//Writing folder data to share point to further process using sharepoint work flow
					sharepointDocumentRepository.createFolderList(map,documentFolder,studyObj,bw);
				}else { // usual folder creation flow
					sharepointDocumentRepository.createFolder(map, documentFolder, studyObj, bw);
					if (null != user && !(user.trim().equals(""))) {
						user = user.trim();
						String itemId = sharepointDocumentRepository.getID(map, documentFolder);
						String principalId = sharepointDocumentRepository.principalId(map, documentFolder, user);
						if (null != principalId && principalId != "") {
							sharepointDocumentRepository.recreatePermission(map, itemId, principalId, documentFolder,permission,studyObj,bw);
						}
					}else {
						String itemId = sharepointDocumentRepository.getID(map, documentFolder);
						user=messages.getString("SystemAccount");
						String principalId = sharepointDocumentRepository.principalId(map, documentFolder, user);
						if (null != principalId && principalId != "") {
							sharepointDocumentRepository.recreatePermission(map, itemId, principalId, documentFolder,permission,studyObj,bw);
						}
					}
				}
			}
		} catch (DocumentScaningException e) {
			result = "fail";
			logger.log(Level.SEVERE, "processFolder : error while process folder ", e.getStackTrace());
		} catch (Exception e) {
			result = "fail";
			logger.log(Level.SEVERE, "processFolder : error while process folder ", e.getStackTrace());
		}
		return result;
	}

	/**
	 * // Release #2 - changes implemented
	 * This method is is the caller to fetch the folders data and process Fodlers to
	 * create in sharepoint site.
	 * @param fileStr
	 * @param batchType
	 * @param qrystartDate
	 * @param qryEndDate
	 * @throws DocumentScaningException
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	public void excuteProcess(String fileStr, String batchType, String qrystartDate, String qryEndDate)
			throws DocumentScaningException, Exception {
		logger.info("excuteProcess Start fileStr===>"+fileStr+"::batchType:"+batchType);
		String strURL = "";
		String strURL2 = "";
		FileInputStream fis = null;
		String createdDt = null;
		String documentFolder = null;
		int count = 0;
		String timestamp = new Timestamp(System.currentTimeMillis()).toString().replaceAll("[^a-zA-Z0-9 _-]", "-");
		logger.info("Time" + timestamp.substring(0, 16));
		File fout = null;
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		File ccs_fout = null;
		FileOutputStream ccs_fos = null;
		BufferedWriter ccs_bw = null;
		boolean coc_flag = false;
		String sysAccount = null;
		String CRACodes[] = null;
		FileInputStream ccs_fis = null;
		BufferedInputStream ccs_bis = null;
		DataInputStream ccs_dis = null;
		
		try {
			String currentDir = System.getProperty("config");
			fis = new FileInputStream(currentDir);
			messages = new PropertyResourceBundle(fis);
			sharepointDatafetch = new MADTSharePointServiceImpl();
			sharepointDatafetch.setMessage(messages);
			sharepointDocumentRepository = new SharePointDocumntRepositoryImpl();
			sharepointDocumentRepository.setMessage(messages);
			String errorFilePath = messages.getString("error_file_path");
			String CCSFilePath = messages.getString("ccs_file_path");
			String file_name = "FC_Err_" + timestamp.substring(0, 16) + ".txt";
			String ccs_file_data = "CCS_File_Data.txt";
			fout = new File(errorFilePath + file_name);
			fos = new FileOutputStream(fout);
			bw = new BufferedWriter(new OutputStreamWriter(fos));
			// Handling CCS Fiel Data
			ccs_fout = new File(CCSFilePath + ccs_file_data);
			
			List<MADTDSStudy> activeListStudyObj = null;
			List<MADTDSStudy> plannedListStudyObj = null;
			List<MADTDSStudy> listStudyObj = null;
			// Defect #2 Added Condition for handling folder data from file.
			if (null != fileStr) {
				logger.info("excuteProcess: inside if");
				listStudyObj = fetchDataFromFile(fileStr);
			} else {
				logger.info("excuteProcess: inside else");
				String userName = messages.getString("impact_userName");
				String CRACode = messages.getString("CRACode");
				String pwd = messages.getString("impact_password");
				String BASEPATH = messages.getString("base_path_api");
				String keyId = messages.getString("keyId");
				logger.info("inside else batchType" + batchType);
				String decPWD = PasswordEncUtil.convert("d", pwd);
				//Release-2- Deals with Cancelled,Completed and Stopped
				if (null != batchType && (batchType.equals("COC_Daily") || batchType.equals("COC_History"))) {
					if(!ccs_fout.exists()) {
						ccs_fos = new FileOutputStream(ccs_fout);
					}
					logger.info("excuteProcess:: inside if - COC_Daily");
					coc_flag = true;
					sysAccount = messages.getString("SystemAccount");
					strURL += "?$filter=(QUERY_TYPE%20eq%20%27S%27)"+strURL+ "%20and%20(SE_LAST_UPDATED_ON%20ge%20datetime%27" + qrystartDate
							+ "%27%20and%20SE_LAST_UPDATED_ON%20lt%20datetime%27" + qryEndDate + "%27)";
					String URL = BASEPATH + strURL;
					logger.info("Impact URL applied before getDataFromImpactSite()===>" + URL);
					String xml = getDataFromImpactSite(URL, userName, decPWD, keyId);
					listStudyObj = fetchDataFromXML(xml);
					// Release-2 - Writing Study list to a file
					logger.info("inside CCS_Daily_History listStudyObj size::==>" +listStudyObj.size());
					updateFileFromList(listStudyObj,ccs_fout);
				}
				//Release-2- Revived Studies - deal with the folders became Active/Planned from Stopped/Cancelled/Completed
				else if (null != batchType && batchType.equals("Revival")) {
					if(!ccs_fout.exists()) {
						ccs_fos = new FileOutputStream(ccs_fout);
					}
					logger.info("excuteProcess:: inside if - Revival");
					sysAccount = messages.getString("SystemAccount");
					BufferedReader br = null;
					List<String> studyDataList = new ArrayList<String>();
					// Reading study list from file for checking in impact whether they got revived.
					try {
						br = new BufferedReader(new FileReader(ccs_fout));
			            String study; 
			            while ((study = br.readLine()) != null) {
			            	logger.info("Study Alias Code:"+study);
			            	studyDataList.add(study);
			            }
			        } catch (IOException e) {
			        	logger.log(Level.SEVERE, "excuteProcess : else if Revival Block : error while reading file ", e.getStackTrace());
			        } 
					finally {
						if(br!= null)
							br.close();
					}
					//Checking for the returned List from Impact. 
					if(null != studyDataList && studyDataList.size()>0) {			
						strURL2 += "?$filter=(QUERY_TYPE%20eq%20%27R%27)";
						String URL = BASEPATH + strURL2;
						logger.info("studyDataList size::"+studyDataList.size());
						//Picking 10 studies lot from studyDataList list and collecting all the returned data impact and processing.
						int size = 10;
						listStudyObj = new ArrayList<MADTDSStudy>();
						List intListStudyObj = null;
					    for (int start = 0; start < studyDataList.size(); start += size) {
					    	URL = BASEPATH + strURL2;
					        int end = Math.min(start + size, studyDataList.size());
					        List<String> studyDataList5 = studyDataList.subList(start, end);
					        logger.info("studyDataList5:::"+studyDataList5);
					        String studydat = null;
					        int count2 =1;
					        studydat = "%20and%20(STUDY_CODE_ALIAS%20eq%20%27";
							for(String studySub:studyDataList5) {
								studySub = URLEncoder.encode(studySub.trim(), "UTF-8").replaceAll(" ", "%20");
								studydat += studySub+ "%27";
								if(count2< studyDataList5.size() ) {
									studydat += "%20or%20STUDY_CODE_ALIAS%20eq%20%27";
								}
								count2++;
							}
							URL+=studydat+")";
						    logger.info("excuteProcess:: inside if - Revival URL"+URL);
					    	String xml = getDataFromImpactSite(URL, userName, decPWD, keyId);
					    	intListStudyObj = new ArrayList<MADTDSStudy>();
					    	intListStudyObj = fetchDataFromXML(xml); 
					    	logger.info("Returned Internal List size  from Impact API : "+intListStudyObj.size());
					    	// Collecting Retuned List from impact
					    	listStudyObj.addAll(intListStudyObj); 
					    	
					    }
					    logger.info("Total Returned List size  from Impact API : "+listStudyObj.size());
						  
					    //Checking the returned List from Impact API to update the local study file.
						if(null!= listStudyObj && listStudyObj.size() >0){
							int countrem = 0;
							for(MADTDSStudy studyobj:listStudyObj) {
								if(studyDataList.contains(studyobj.getStudyId())){
									studyDataList.remove(studyobj.getStudyId());							
								}
								countrem++;
							}
							//Release #2 - Method being called to update the data in the file
							logger.info("Inside Revival :: studyDataList Size  after remove before refreshing file==>"+studyDataList.size());
							updateFile(studyDataList,ccs_fout);
						}
					}
					else {
						logger.info("!!!!! There are no studies available in file folder so batch for Revival is exiting !!!!!");
					}
				}
				// Release #2 - Added Condition to deal with folders  active/planned based on Creation Date
				else {
					
					logger.info("****excuteProcess:: inside if - Else - daily batch****");
					// Retrieving the folder for status = 'A'				

					// Adding as part of clean up - remove access for CRA 
					if(null!= batchType && batchType.equalsIgnoreCase("CleanUp")) {
						strURL += "?$filter=(QUERY_TYPE%20eq%20%27A%27)%20and%20(SSP_END_DATE%20ge%20datetime%27" + qrystartDate + "%27%20and%20SSP_END_DATE%20lt%20datetime%27" + qryEndDate + "%27)";
					}
					else {
						strURL += "?$filter=(QUERY_TYPE%20eq%20%27A%27)%20and%20((SSP_LAST_UPDATED_ON%20ge%20datetime%27" + qrystartDate+"%27%20and%20SSP_LAST_UPDATED_ON%20lt%20datetime%27" + qryEndDate + "%27)"
								+ "%20or%20(SE_LAST_UPDATED_ON%20ge%20datetime%27" + qrystartDate + "%27%20and%20SE_LAST_UPDATED_ON%20lt%20datetime%27" + qryEndDate + "%27)"
								+ "%20or%20(SSP_END_DATE%20ge%20datetime%27" + qrystartDate + "%27%20and%20SSP_END_DATE%20lt%20datetime%27" + qryEndDate + "%27))";
					}
					String URL = BASEPATH + strURL;
					logger.info("Impact URL applied before getDataFromImpactSite() for QUERY_TYPE = 'A' ===>" + URL);
					String xml = getDataFromImpactSite(URL, userName, decPWD, keyId);
					activeListStudyObj = fetchDataFromXML(xml);
					logger.info("activeListStudyObj====>"+activeListStudyObj.size());
					// Retrieving the folder for status = 'P'
			
					// Adding as part of clean up - remove access for CRA 
					if(null!= batchType && batchType.equalsIgnoreCase("CleanUp")) {
						strURL2 += "?$filter=(QUERY_TYPE%20eq%20%27P%27)%20and%20(SSP_END_DATE%20ge%20datetime%27" + qrystartDate + "%27%20and%20SSP_END_DATE%20lt%20datetime%27" + qryEndDate + "%27)";
					}
					else {
						strURL2 += "?$filter=(QUERY_TYPE%20eq%20%27P%27)%20and%20((SSP_LAST_UPDATED_ON%20ge%20datetime%27" + qrystartDate+"%27%20and%20SSP_LAST_UPDATED_ON%20lt%20datetime%27" + qryEndDate + "%27)"
								+ "%20or%20(SE_LAST_UPDATED_ON%20ge%20datetime%27" + qrystartDate + "%27%20and%20SE_LAST_UPDATED_ON%20lt%20datetime%27" + qryEndDate + "%27)"
								+ "%20or%20(SSP_END_DATE%20ge%20datetime%27" + qrystartDate + "%27%20and%20SSP_END_DATE%20lt%20datetime%27" + qryEndDate + "%27))";
					}
					URL = BASEPATH + strURL2;
					logger.info("Impact URL applied before getDataFromImpactSite() for QUERY_TYPE = 'P' ===>" + URL);
					
					xml = getDataFromImpactSite(URL, userName, decPWD, keyId);
					
					plannedListStudyObj = fetchDataFromXML(xml);
					
					listStudyObj = new ArrayList<MADTDSStudy>();
					//listStudyObj = new CopyOnWriteArrayList<MADTDSStudy>();
					List<MADTDSStudy> addList = new ArrayList<MADTDSStudy>();
					List<MADTDSStudy> removeList = new ArrayList<MADTDSStudy>();
					logger.info("plannedListStudyObj Size====>"+plannedListStudyObj.size());
					listStudyObj.addAll(activeListStudyObj);
					listStudyObj.addAll(plannedListStudyObj);
					logger.info("Else:: Daily/Manual listStudyObj Size b4 removing ====>"+listStudyObj.size());
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					
					Date startDate=null;
			        Date checkDate=null;
			        startDate=sdf.parse(qrystartDate);
			        logger.info("startDate::"+startDate);
			        MADTDSStudy studyObj = null;
			        //discarding the folders if the ssp end date is older to current date/Start Date incase of history.
			        if(null!= listStudyObj){
				        for(int i = 0; i<listStudyObj.size(); i++) {
				        	studyObj = listStudyObj.get(i);
				        	if(null != studyObj.getSspEndDt()) {
								 checkDate=sdf.parse(studyObj.getSspEndDt());
						         if(checkDate.before(startDate)){
						        	listStudyObj.remove(studyObj);
								}
							}		
						}
			        }
				}
			}
			logger.info("listStudyObj size b4 processing::"+listStudyObj.size());
			if(null!= listStudyObj && listStudyObj.size() > 0) {
				// Using HashMap tree for counting the number folder to be created in sharepoint
				HashMap<String, HashMap<String, HashMap<String, String>>> hm = new HashMap<String, HashMap<String, HashMap<String, String>>>();
				HashMap<String, HashMap<String, String>> cHashMap = new HashMap<String, HashMap<String, String>>();
				HashMap<String, String> sHaspMap = new HashMap<String, String>();
				SimpleDateFormat sdfo = new SimpleDateFormat("yyyy-MM-dd"); 
				String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		        Date sysDate = sdfo.parse(date);
		        Date sspEndDate = null;
		        boolean remove_flag = false;
		        String sEndDt = null;
		        Date startDate=null;
		        Date endDate=null;
		        if(null != qrystartDate) 
		        	startDate=sdfo.parse(qrystartDate);
		        if(null != qryEndDate) 
		        	endDate=sdfo.parse(qryEndDate);
		        logger.info("inside if : startDate::"+startDate);
				logger.info("inside if : endDate::"+endDate);
				
				for (MADTDSStudy studyObj : listStudyObj) {
					String key = studyObj.getStudyId();
					String country = studyObj.getCountry();
					String site = studyObj.getSiteId();
					if (!hm.containsKey(key)) {
						cHashMap = new HashMap<String, HashMap<String, String>>();
						if (country != null && country.trim().length() > 0) {
							if (site != null && site.trim().length() > 0) {
								sHaspMap = new HashMap<String, String>();
								sHaspMap.put(site, site);
								count++;
							}
							cHashMap.put(country, sHaspMap);
							count++;
						}
						hm.put(key, cHashMap);
						count++;
					} else {
						cHashMap = hm.get(key);
						if (country != null && country.trim().length() > 0) {
							if (!cHashMap.containsKey(country)) {
								sHaspMap = new HashMap<String, String>();
								if (site != null & site.trim().length() > 0) {
									sHaspMap.put(site, site);
									count++;
								}
								cHashMap.put(country, sHaspMap);
								count++;
							} else {
								sHaspMap = cHashMap.get(country);
								if (site != null && site.trim().length() > 0) {
									if (!sHaspMap.containsKey(site)) {
										sHaspMap.put(site, site);
										count++;
									}
								}
							}
						}
					}
					//Release #2 - Changes implemented
					
					if (coc_flag) {
						documentFolder = "Shared%20Documents";
						if(null!= studyObj && null!= studyObj.getStudyId() && !(studyObj.getStudyId().trim().equals(""))) {
							documentFolder += "/" + studyObj.getStudyId().replaceAll("[^a-zA-Z0-9 _-]", "").replace(" ", "%20").trim();
							processFolder(documentFolder, sysAccount, studyObj, bw, coc_flag,false);
						}
					} else {
						sEndDt = studyObj.getSspEndDt();
						sspEndDate = null; //// Resetting sspEndDate
						remove_flag = false; // Resetting flag
						logger.info("sEndDt===>"+sEndDt);
						if(null != sEndDt)
							sspEndDate = sdfo.parse(sEndDt);
						
						documentFolder = "Shared%20Documents";
						//Checking for SSP End date is not null, today or older to remove access for CRA
						//if(null != sEndDt && (sspEndDate.compareTo(sysDate) == 0) || (sspEndDate.compareTo(sysDate) == -1))
						logger.info("inside if : sspEndDate::"+sspEndDate);
						if(null != sspEndDate && ((sspEndDate.after(startDate) && sspEndDate.before(endDate)) || sspEndDate.equals(startDate) || sspEndDate.equals(endDate)))
							remove_flag = true;
										
						logger.info("remove_flag===>"+remove_flag);
						if(remove_flag) {
							if(null!= studyObj && null!= studyObj.getSiteId() && !(studyObj.getSiteId().trim().equals(""))) {
								documentFolder += "/"+ studyObj.getSiteId().replaceAll("[^a-zA-Z0-9 _-]", "").replace(" ", "%20").trim();
								processFolder(documentFolder, studyObj.getCRAName(), studyObj, bw, coc_flag,remove_flag);
							}
						}else {
							if(null!= studyObj && null!= studyObj.getStudyId() && !(studyObj.getStudyId().trim().equals(""))) {
								documentFolder += "/"+ studyObj.getStudyId().replaceAll("[^a-zA-Z0-9 _-]", "").replace(" ", "%20").trim();
								processFolder(documentFolder, studyObj.getCRAName(), studyObj, bw, coc_flag,remove_flag);
								if(null!= studyObj && null!= studyObj.getCountry() && !(studyObj.getCountry().trim().equals(""))) {
									documentFolder += "/"+ studyObj.getCountry().replaceAll("[^a-zA-Z0-9 _-]", "").replace(" ", "%20").trim();
									processFolder(documentFolder, studyObj.getCRAName(), studyObj, bw, coc_flag,remove_flag);
									if(null!= studyObj && null!= studyObj.getSiteId() && !(studyObj.getSiteId().trim().equals(""))) {
										documentFolder += "/"+ studyObj.getSiteId().replaceAll("[^a-zA-Z0-9 _-]", "").replace(" ", "%20").trim();
										processFolder(documentFolder, studyObj.getCRAName(), studyObj, bw, coc_flag,remove_flag);
									}
								}
							}
						}
					}
				}//End for loop
			}else {
				logger.info("****There are no folders from Impact to Process ****");
			}

		} catch (DocumentScaningException e) {
			logger.log(Level.SEVERE, "excuteProcess : error while process folder ", e.getStackTrace());
			throw e;

		} catch (Exception e) {
			logger.log(Level.SEVERE, "excuteProcess : error while process folder ", e.getStackTrace());
			e.printStackTrace();
			throw e;
		} finally {
			logger.info("Total Folders available to create in sharepoint are==>" + count);
			if (bw != null)
				bw.close();
			if (fos != null)
				fos.close();

		}
		logger.info("excuteProcess End ===>");
	}

	/**
	 * Authenticate and fetch the folders data from the Impact site
	 * 
	 * @param URL
	 * @param userName
	 * @param passWord
	 * @throws Exception
	 */
	public String getDataFromImpactSite(String URL, String userName, String password, String kayCode) throws Exception {
		
		logger.info("getDataFromImpactSite ===> Start");
		String pwd = "changeit";
		// LoadExtKey(keyPath,pwd);
		StringBuffer output = new StringBuffer("");
		try {
			SSLContext sslContext = SSLContexts.createSystemDefault();
	
			SSLConnectionSocketFactory f = new SSLConnectionSocketFactory(sslContext, new String[] { "TLSv1.2" }, null,
					SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	
			Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
					.register("http", PlainConnectionSocketFactory.getSocketFactory()).register("https", f).build();
	
			PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
			
				CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(f).setConnectionManager(cm).build();
				HttpGet getRequest = new HttpGet(URL);
				getRequest.setHeader("Authorization",
						"Basic " + Base64.encodeBase64String((userName + ":" + password).getBytes()));
				getRequest.setHeader("KeyId", kayCode);
				HttpResponse response = httpClient.execute(getRequest);
				
				String data;
				BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
		
				while ((data = br.readLine()) != null) {
					output.append(data);
				}
			logger.info("MADTFolderCreationBatchJob : getDataFromImpactSite: End");
		}catch(Exception e) {
			logger.log(Level.SEVERE, "getDataFromImpactSite : error while fetching data from Impact:", e.getStackTrace());
			throw new DocumentScaningException("error while getDataFromImpactSite " + e);
		}
		return output.toString();
	}

	/**
	 * Used to fetch the data from XML
	 * @param xmlString
	 * @throws Exception
	 * @return listStudyObj
	 */
	public List<MADTDSStudy> fetchDataFromXML(String xmlString) throws Exception{
		logger.info("fetchDataFromXML ===> Start");
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		List<MADTDSStudy> listStudyObj = new ArrayList<MADTDSStudy>();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			StringBuilder xmlStringBuilder = new StringBuilder();
			xmlStringBuilder.append(xmlString);
			ByteArrayInputStream input = new ByteArrayInputStream(xmlStringBuilder.toString().getBytes("UTF-8"));
			Document doc = builder.parse(input);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("entry");
			logger.info("fetchDataFromXML :: nList.getLength()====>" + nList.getLength());
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					MADTDSStudy studyObj = new MADTDSStudy();

					if (null != eElement.getElementsByTagName("d:STUDY_CODE_ALIAS")
							&& null != eElement.getElementsByTagName("d:STUDY_CODE_ALIAS").item(0)) {
						studyObj.setStudyId(
								eElement.getElementsByTagName("d:STUDY_CODE_ALIAS").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:COUNTRY_DESC")
							&& null != eElement.getElementsByTagName("d:COUNTRY_DESC").item(0)) {
						studyObj.setCountry(eElement.getElementsByTagName("d:COUNTRY_DESC").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:SITE_ID")
							&& null != eElement.getElementsByTagName("d:SITE_ID").item(0)) {
						studyObj.setSiteId(eElement.getElementsByTagName("d:SITE_ID").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:PERSONNEL_ID")
							&& null != eElement.getElementsByTagName("d:PERSONNEL_ID").item(0)
							&& eElement.getElementsByTagName("d:PERSONNEL_ID").item(0).getTextContent() != "") {
						studyObj.setCRAName(eElement.getElementsByTagName("d:PERSONNEL_ID").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:SS_CREATED_ON")
							&& null != eElement.getElementsByTagName("d:SS_CREATED_ON").item(0)
							&& eElement.getElementsByTagName("d:SS_CREATED_ON").item(0).getTextContent() != "") {
						studyObj.setCreatedDt(eElement.getElementsByTagName("d:SS_CREATED_ON").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:S_ESB_LAST_UPDATED_DATE")
							&& null != eElement.getElementsByTagName("d:S_ESB_LAST_UPDATED_DATE").item(0) && eElement
									.getElementsByTagName("d:S_ESB_LAST_UPDATED_DATE").item(0).getTextContent() != "") {
						studyObj.setUpdDt(eElement.getElementsByTagName("d:S_ESB_LAST_UPDATED_DATE").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:SSP_END_DATE")
							&& null != eElement.getElementsByTagName("d:SSP_END_DATE").item(0) && eElement
									.getElementsByTagName("d:SSP_END_DATE").item(0).getTextContent() != "") {
						studyObj.setSspEndDt(eElement.getElementsByTagName("d:SSP_END_DATE").item(0).getTextContent());
					}
					if (null != eElement.getElementsByTagName("d:STUDY_STATUS_DESC")
							&& null != eElement.getElementsByTagName("d:STUDY_STATUS_DESC").item(0) && eElement
									.getElementsByTagName("d:STUDY_STATUS_DESC").item(0).getTextContent() != "") {
						studyObj.setStudyStatus(eElement.getElementsByTagName("d:STUDY_STATUS_DESC").item(0).getTextContent());
					}
					
					listStudyObj.add(studyObj);
				}
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "fetchDataFromXML : error while fetching data from XML:", e.getStackTrace());
			e.printStackTrace();
			throw new DocumentScaningException("error while fetchDataFromXML " + e);
		}
		logger.info("fetchDataFromXML ===> End");
		return listStudyObj;
	}

	/**
	 * This method is used to read the missing folders data from file
	 * 
	 * @param strFile
	 * @throws Exception
	 * @return listStudyObj
	 */
	public List<MADTDSStudy> fetchDataFromFile(String strFile) throws Exception{
		logger.info("fetchDataFromXML ===> Start");

		StringTokenizer tokenizer;
		List<MADTDSStudy> listStudyObj = null;
		String theLine;
		String studyId = null;
		String siteId = null;
		String country = null;
		String CRACode = null;
		File textFile = null;
		Scanner inputFile = null;
		try {
			textFile = new File(strFile);
			inputFile = new Scanner(textFile);
			listStudyObj = new ArrayList<MADTDSStudy>();
			while (inputFile.hasNext()) {
				theLine = inputFile.nextLine();
				tokenizer = new StringTokenizer(theLine, "/");
				MADTDSStudy studyObj = new MADTDSStudy();
				while (tokenizer.hasMoreTokens()) {
					studyId = tokenizer.nextToken();
					country = tokenizer.nextToken();
					siteId = tokenizer.nextToken();
					CRACode = tokenizer.nextToken();

					studyObj.setStudyId(studyId);
					studyObj.setCountry(country);
					studyObj.setSiteId(siteId);
					studyObj.setCRAName(CRACode);
				}
				listStudyObj.add(studyObj);
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, "fetchDataFromXML :" + e.getMessage());
			throw new DocumentScaningException("error while fetchDataFromFile " + e);
		} finally {
			if (inputFile != null) {
				inputFile.close();
			}
		}
		return listStudyObj;
	}
/**
 * Recreate the file after refreshing the studies. 
 * @param studyDataList
 * @param ccs_fout
 */
private void updateFile(List<String> studyDataList, File ccs_fout) {
	logger.info("updateFile:Inside updateFile studyDataList Size:"+studyDataList.size());
	
	FileWriter fw = null;
	BufferedWriter pw = null;
	try {
		if(ccs_fout.exists()){
			ccs_fout.delete();
			ccs_fout.createNewFile();
			logger.info("File Created");
   	  	}
		fw = new FileWriter(ccs_fout,true);
		pw = new BufferedWriter(fw);
		
		for (String study:studyDataList){
			try {
				logger.info("study==>"+study);
				pw.write(study);
				pw.newLine();
			}
			catch (IOException e) {
				logger.log(Level.SEVERE, "updateFile :  error while writing to file ", e.getStackTrace());
			 } 
		}  
	
	}catch(Exception e) {
		logger.log(Level.SEVERE, "updateFile :  error while writing to file ", e.getStackTrace());
	}finally {
		try {
			if(pw!=null)
				pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			if(fw!=null)
				fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

/**
 * Update the file, include new studies for Completed,Cancelled and Stopped studies
 * @param listStudyObj
 * @param ccs_fout
 */
	private void updateFileFromList(List<MADTDSStudy> listStudyObj, File ccs_fout) {
		logger.info("studyDataList after remove::" + listStudyObj.toString());
		;
		FileWriter fw = null;
		BufferedWriter pw = null;
		try {
			if (!ccs_fout.exists()) {
				ccs_fout.createNewFile();
				logger.info("File Created");
			}
			fw = new FileWriter(ccs_fout, true);
			pw = new BufferedWriter(fw);

			for (int i = 0; i < listStudyObj.size(); i++) {
				try {
					pw.write(listStudyObj.get(i).getStudyId());
					pw.newLine();
				} catch (Exception e) {
					logger.log(Level.SEVERE, "updateFileFromList :  if COC_Daily Block : error while writing to file ",
							e.getStackTrace());
					e.printStackTrace();
				}

			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "updateFileFromList :  if COC_Daily Block : error while writing to file ",
					e.getStackTrace());
		} finally {
			try {
				if (pw != null)
					pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				if (fw != null)
					fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}// End of class