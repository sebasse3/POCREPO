package com.novartis.madt.repositoryimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import org.apache.commons.io.FileUtils;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.util.PasswordEncUtil;

public class TestSharePointLocal {

	public static void main(String[] args) {
		MADTSharePointServiceImpl madtObj = new MADTSharePointServiceImpl();
		String currentDir = "C:\\seb\\DRS2_ams\\DocumentScanningSolution\\mobiletmf\\src\\config.properties";

		System.out.println("java.home"+System.getProperty("java.home"));

		try {
			InputStream fis = new FileInputStream(currentDir);
			ResourceBundle messages = new PropertyResourceBundle(fis);
			madtObj.setMessage(messages);
			System.out.println("Start");
			String wctx = madtObj.getWCTX();
			System.out.println("wctx:"+wctx);
			//String userName = "SYS_MOTION_MADT@novartis.net";
			//String password = "7RtprXNutqXP7+Oe6V1F7g==";
			String userName = "sebin.sebastian@novartis.com";
			String password = "p1FUcM4puDvToPnCCzh/ew==";
			String decPWD = PasswordEncUtil.convert("d", password);
			//System.out.println(decPWD);
			String adfsToken = madtObj.getADFSToken(userName, decPWD);
			//System.out.println("adfsToken:"+adfsToken);
			
			
			String t = madtObj.getADFSTParam(wctx, adfsToken);
			System.out.println("t:"+t);
			
			String cookies = madtObj.getFedAuth(t);
			//System.out.println("cookies:"+cookies);
			
			String formDgToken = madtObj.getFormDigest(cookies);
			//System.out.println("formDgToken:"+formDgToken);
			
			Map<String, String> map = new HashMap<>();
			map = new HashMap<>();
			map.put("accessToken", t);
			map.put("cookies", cookies);
			map.put("formDgToken", formDgToken);
			
			String cookie=map.get("cookies");
			//System.out.println("cookie:"+cookie);
			
			URL url;
			url = new URL(null,"https://share.novartis.net/:w:/r/sites/PharmaAssetsTest/POC2/_layouts/15/Doc.aspx?sourcedoc=%7B94D394D1-B6C9-4FB7-835C-8E655680F3E5%7D&file=Setup%20TFS%20in%20Eclipse.docx&action=default&mobileredirect=true",new sun.net.www.protocol.https.Handler());
			//url = new URL(null,"https://share.novartis.net/:x:/r/sites/mobiletmf-repository_dev/_layouts/15/Doc.aspx?sourcedoc=%7B64310612-4AF8-40FE-A456-B405A8292A26%7D&file=Mobile_Scanning_TMF_%E2%80%93_DEV_Audit_Log_2018-11-03T000424.xlsx&action=default&mobileredirect=true",new sun.net.www.protocol.https.Handler());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(10000);
			if ((cookie == null) || cookie.isEmpty()) {
			} else {
				conn.setRequestProperty("Cookie", cookie);
			}
			conn.setRequestProperty("Accept", "application/json");
			conn.connect();
			FileUtils.copyInputStreamToFile(conn.getInputStream(),new File("C:/seb/test/Test.html"));
			//FileUtils.copyInputStreamToFile(conn.getInputStream(),new File("downloadPath"+"fileName"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
