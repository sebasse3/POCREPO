package com.novartis.madt.repositoryimpl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.novartis.madt.constants.JMADTConstants;
import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.model.ListItem;
import com.novartis.madt.model.MADTDSStudy;
import com.novartis.madt.repository.DocumentRepository;
@Service
public class SharePointDocumntRepositoryImpl implements DocumentRepository{

	Logger logger = Logger.getLogger(SharePointDocumntRepositoryImpl.class.getSimpleName());

	
	private ResourceBundle messages=null;

	public void setMessage(ResourceBundle messages) {
		this.messages = messages;
	}

	/**
	 * This method is used to hit the GET method of rest service 
	 * @param cookie
	 * @param accessToken
	 * @param url
	 * @return
	 * @throws DocumentScaningException
	 */
	private HttpResponse getHttpResponse(String cookie, String accessToken, String url)
			throws DocumentScaningException {

		HttpResponse response = null;
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(url);
		httpGet.setHeader("Authorization", accessToken);
		httpGet.addHeader("Cookie", cookie);

		try {
			response = client.execute(httpGet);
		} catch (ClientProtocolException e) {
			logger.log(Level.SEVERE, "error clientprotocol exception ", e);

			throw new DocumentScaningException("error clientprotocol exception " + e.getMessage());
		} catch (IOException e) {
			logger.log(Level.SEVERE, "error IOException", e);
			throw new DocumentScaningException("error IOException " + e.getMessage());
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while calling API ", e);
			throw new DocumentScaningException("error while calling API " + e.getMessage() + e);
		}
		return response;
	}
	/**
	 * This method is used to hit the GET method of rest service 
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param url
	 * @return
	 * @throws DocumentScaningException
	 */
	private HttpResponse postHttpResponse(String cookie, String accessToken, String formdgToken, String url)
			throws DocumentScaningException {
		HttpResponse response = null;
		try {
			HttpClient client = HttpClientBuilder.create().build();
			HttpPost httpPost = new HttpPost(url);
			httpPost.setHeader("Authorization", accessToken);
			httpPost.setHeader("X-RequestDigest", formdgToken);
			httpPost.addHeader("Cookie", cookie);
			response = client.execute(httpPost);
		} catch (ClientProtocolException e) {
			logger.log(Level.SEVERE, "error clientprotocol exception ", e);
			throw new DocumentScaningException("clientprotocol exception " + e.getMessage() + e);
		} catch (IOException e) {
			logger.log(Level.SEVERE, "error IOException", e);
			throw new DocumentScaningException("IOException " + e.getMessage() + e);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while calling API ", e);
			throw new DocumentScaningException("error while calling API " + e.getMessage() + e);
		}
		return response;

	}
	/**
	 * This method is used to download the file from sharepoint site.
	 * @param cookie
	 * @param fileName
	 * @param documentFolder
	 * @throws Exception
	 */
	@Override
	public void download(Map<String,String> map, String fileName, String documentFolder) throws Exception {
		HttpURLConnection conn=null;
		try {
			String cookie=map.get("cookies");
			String urlString = messages.getString("baseurl")+messages.getString("downloadurl") + documentFolder + "')/Files('" + fileName
					+ "')/$value";
			URL url = null;
			try {
				url = new URL(null,urlString,new sun.net.www.protocol.https.Handler());
			} catch (MalformedURLException e) {
				logger.log(Level.SEVERE, "MalformedURLException while downloading  ", e);
				throw new Exception("error:Invalid URL." + e.getMessage());
			}
			
			conn = (HttpURLConnection) url.openConnection();
			conn.setConnectTimeout(10000);
			if ((cookie == null) || cookie.isEmpty()) {
			} else {
				conn.setRequestProperty("Cookie", cookie);
			}
			conn.setRequestProperty("Accept", "application/json");
			conn.connect();
			if (conn.getResponseCode() == 403) {
				throw new Exception("{\"error\":\"403 Forbidden\"}");
			}

			if (conn.getResponseCode() == 200) {
				String basePath = messages.getString("basepath");
				String downloadPath =  basePath + messages.getString("pdfinput");
				FileUtils.copyInputStreamToFile(conn.getInputStream(),new File(downloadPath+fileName));
				logger.info("document  download completed   " + conn.getResponseCode());
			} else if (conn.getResponseCode() < 200 || conn.getResponseCode() > 300) {
				logger.warning("error while downloading : " + conn.getResponseCode());
				throw new Exception("{\"error\":\"" + conn.getResponseCode() + "\"}");
			}
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while downloading.", e);
			throw new Exception("error while downloading." + e.getMessage());
		}
		finally{
			if(null != conn)
			conn.disconnect();
		}
	}

	/**
	 * This method is used to checkout from sharepoint site.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param fileName
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	public int checkout(Map<String,String>map, String fileName, String documentFolder)
			throws DocumentScaningException {

		String url = messages.getString("baseurl")+messages.getString("checkouturl")+documentFolder+"')/Files('"
				+fileName+"')/CheckOut()";
		logger.info(url);
		int responseCode = 0;
		String cookie=map.get("cookies");
		String accessToken=map.get("accessToken");
		String formdgToken=map.get("formDgToken");
		try {
			HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
				logger.info("checkout Response Code" + responseCode);
				if ((responseCode < 200 || responseCode > 300) && !(responseCode == 423)) {
					throw new DocumentScaningException("check out response code  :   " + responseCode);
				}
				/*if (responseCode == 423) {
					int discardResponseCode = discard(cookie, accessToken, formdgToken, fileName, documentFolder);
					logger.info("dicard Response Code  " + responseCode);
					if (discardResponseCode == 200) {
						checkout(cookie, accessToken, formdgToken, fileName, documentFolder);
					}
				}*/
			}
			return responseCode;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error getting while checkout ", e);
			throw new DocumentScaningException("error getting while checkout " + e.getMessage());
		}

	}
	/**
	 * This method is used to discard if already checkout is there in sharepoint
	 * This method is used to checkout from sharepoint site.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param fileName
	 * @param documentFolder
	 * @return response code
	 * @throws DocumentScaningException
	 */
	@Override
	public int discard(Map<String,String>map, String fileName, String documentFolder)
			throws DocumentScaningException {

		int responseCode = 0;
		String url = messages.getString("baseurl") + messages.getString("discardurl") + documentFolder + "')/Files('"
				+ fileName + "')/UndoCheckOut()";
		String cookie=map.get("cookies");
		String accessToken=map.get("accessToken");
		String formdgToken=map.get("formDgToken");

		try {
			HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			logger.info("discard response code  " + responseCode);
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException("discard response code : " + responseCode);
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, " error while calling discard ", e);
			throw new DocumentScaningException(" error while calling discard " + e.getMessage());
		}
		return responseCode;

	}
	/**
	 * This method is used to checkin after upload into sharepoint.
	 * This method is used to checkout from sharepoint site.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param fileName
	 * @param documentFolder
	 * @throws DocumentScaningException
	 */
	@Override
	public void checkIn(Map<String,String>map, String fileName, String documentFolder,String loger)
			throws DocumentScaningException {

		String url = messages.getString("baseurl") + messages.getString("checkinurl") + documentFolder + "')/Files('"
				+ fileName + "')/CheckIn(comment='"+loger+"',checkintype=0)";
		int responseCode = 0;
		String cookie=map.get("cookies");
		String accessToken=map.get("accessToken");
		String formdgToken=map.get("formDgToken");
		try {
			HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException(" checkin response code : " + responseCode);
			}
			logger.info(" Checkin permission  response code  " + responseCode);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while checkIn ", e);
			throw new DocumentScaningException("error while checkIn " + e.getMessage());
		}

	}
	/**
	 * This method is used to upload into sharepoint.
	 * This method is used to checkout from sharepoint site.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param fileName
	 * @param documentFolder
	 * @param pdfFolder
	 * @param bflag
	 * @throws DocumentScaningException
	 */
	@Override
	public String upload(Map<String,String>map, String fileName, String documentFolder,String pdfFolder,boolean bflag)
			throws DocumentScaningException {
		String file_name = "";
		int httpStatus = 0;
		String cookie=map.get("cookies");
		String accessToken=map.get("accessToken");
		String formdgToken=map.get("formDgToken");
		HttpClient client = HttpClientBuilder.create().build();
		//Release #2 Change - checking for color document
		if(bflag) {
			file_name = fileName.substring(0, fileName.lastIndexOf('.'));
			file_name = file_name+"_Original.pdf";
		}else {
			file_name = fileName;
		}
		//System.out.println("file_Name---->>>"+file_name);
		String url = messages.getString("baseurl") + messages.getString("uploadurl") + documentFolder
				+ "')/Files/add(url='" +file_name + "',overwrite=true)";
		try {
			HttpPost post = new HttpPost(url);
			post.setHeader("Authorization", accessToken);
			post.setHeader("X-RequestDigest", formdgToken);

			post.addHeader("Cookie", cookie);

			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			String basePath = messages.getString("basepath");
			String uploadPath =  basePath + messages.getString(pdfFolder);
			File file = new File(uploadPath+file_name);
			
			builder.addPart("fileParamName", new FileBody(file));
			post.setEntity(builder.build());
			HttpResponse response = client.execute(post);
			if (null != response && null != response.getStatusLine()) {
				httpStatus = response.getStatusLine().getStatusCode();
			}
			String responseMsg = EntityUtils.toString(response.getEntity(), "UTF-8");
			logger.info("upload response code  : " + httpStatus);

			// If the returned HTTP response code is not in 200 series then
			// throw the error
			if (httpStatus < 200 || httpStatus > 300) {
				logger.log(Level.SEVERE, "error while uploading " + httpStatus);
				throw new IOException("HTTP " + httpStatus + " - Error during upload of file: " + responseMsg);
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while uploading  ", e);
			throw new DocumentScaningException("error while uploading " + e.getMessage());
		}
		return file_name;
	}

	
	/**
	 * This method is used to update the status of document 
	 * @param map Map
	 * @param documentFolder String
	 * @param hmap Map
	 * @return responseCode int
	 * @throws DocumentScaningException
	 * _api/web/GetFileByServerRelativeUrl('/sites/docs/Email/TestFolder/testMail.msg')
	 */
	@Override
	public int update(Map<String,String>map, String documentFolder,Map<String,String> hmap)
			throws DocumentScaningException {
		int responseCode = 0;
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			String type=messages.getString("type");
			String updateColumn=messages.getString("updateColumn");
			HttpClient client = HttpClientBuilder.create().build();
			logger.info("file path "+documentFolder); 
			String url=messages.getString("baseurl") + messages.getString("updateList")+documentFolder+"')/ListItemAllFields";
			HttpPost httpPost = new HttpPost(url);
			httpPost.setHeader("Authorization", accessToken);
			httpPost.addHeader("Cookie", cookie);
			httpPost.setHeader("X-RequestDigest", formdgToken);
			httpPost.setHeader("Content-Type", "application/json;odata=verbose");
			httpPost.setHeader("X-HTTP-Method", "MERGE");
			httpPost.setHeader("IF-MATCH", "*");
			//Release #2 - Adding status column for color document being uploaded
			String json = "{\"__metadata\" : {\"type\": \""+type+"\"}, \"Status\": \""+hmap.get("status")+"\"}";
			StringEntity entity = new StringEntity(json);
		    httpPost.setEntity(entity);
			HttpResponse response = client.execute(httpPost);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			logger.info("update  response code  " + responseCode);
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException("while getting  update list to sharepoint response ,Response CODE: " + responseCode);
			}
			} catch (UnsupportedOperationException | IOException e) {
			logger.log(Level.SEVERE, "error while gettign update the status ", e);
			throw new DocumentScaningException("error while gettign update the status " + e.getMessage());
		}
		catch (Exception e) {
			logger.log(Level.SEVERE, "error while gettign update the status ", e);
			throw new DocumentScaningException("error while gettign update the status " + e.getMessage());
		}
		return responseCode;
	}
	
	
	
	/**
	 * This method is used to getLIst from sharepoint site.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param fileName
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	@Override
	public List<String> getPendingList(Map<String,String>map)
			throws DocumentScaningException {

		List<String> idList=new ArrayList<>();
		String sharePointLibraryName=messages.getString("sharePointLibraryName");
		String docuementStatusColumn=messages.getString("docuementStatusColumn");
		String pendingConversion=messages.getString("pendingConversion");
		String listurl=messages.getString("baseurl")+ messages.getString("getList")+sharePointLibraryName+"')/items?$filter="+docuementStatusColumn+"%20eq%20%27"+pendingConversion+"%27";
		int responseCode = 0;
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			HttpResponse response = getHttpResponse(cookie, accessToken,  listurl);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
				logger.info("listITem Response Code" + responseCode);
				if ((responseCode < 200 || responseCode > 300) && !(responseCode == 423)) {
					throw new DocumentScaningException("check out response code  :   " + responseCode);
				}
				String fileName=null;
				String filePath=null;
				if (null != response && null != response.getEntity()) {
					InputStream in = response.getEntity().getContent();

					try (BufferedReader buffer = new BufferedReader(new InputStreamReader(in))) {
						String inputLine;
						String xml=null;;
			            while ((inputLine = buffer.readLine()) != null)
			            {
			               xml = inputLine;
			               
			            }
			        	final java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("<d:Id(.*?)[>](.*?)</d:Id>");
						final Matcher matcher = pattern.matcher(xml);
						while(matcher.find()) {
							ListItem listItem=new ListItem();
							fileName = matcher.group(2);
							idList.add(fileName);
							
						} 
			 
					}
					
				}
				
			}
			return idList;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error getting while checkout ", e);
			throw new DocumentScaningException("error getting while checkout " + e.getMessage());
		}

	}
	/**
	 * This method is used to get document List based on id from sharepoint site.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * id
	 * @return ListItem
	 * @throws DocumentScaningException
	 */
	@Override
	public List<ListItem> documentList(Map<String,String>map,int id)
			throws DocumentScaningException {

		String sharePointLibraryName=messages.getString("sharePointLibraryName");
		
		String listurl=messages.getString("baseurl") + messages.getString("documentList")+sharePointLibraryName+"')/Items("+id+")/File";
		int responseCode = 0;
		java.util.List<ListItem> list=new ArrayList<ListItem>();
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			HttpResponse response = getHttpResponse(cookie, accessToken,  listurl);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
				logger.info("listITem Response Code" + responseCode);
				if ((responseCode < 200 || responseCode > 300)) {
					throw new DocumentScaningException("document List response code  :   " + responseCode);
				}
				String fileName=null;
				String filePath=null;
				if (null != response && null != response.getEntity()) {
					InputStream in = response.getEntity().getContent();

					try (BufferedReader buffer = new BufferedReader(new InputStreamReader(in))) {
						String inputLine;
						String xml=null;;
			            while ((inputLine = buffer.readLine()) != null)
			            {
			               xml = inputLine;
			               
			            }
			            list=fetchDataFromXML(xml);	
					}
					
				}
				
			}
			return list;
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error getting while document List ", e);
			throw new DocumentScaningException("error getting while document List " + e.getMessage());
		}

	}
	/**
	 * 
	 * @param xmlString
	 */
	public static List<ListItem> fetchDataFromXML(String xmlString) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		List<ListItem> listItemObj = new ArrayList<ListItem>();
		try {
			
			DocumentBuilder builder = factory.newDocumentBuilder();
			StringBuilder xmlStringBuilder = new StringBuilder();
			xmlStringBuilder.append(xmlString);
			ByteArrayInputStream input = new ByteArrayInputStream(xmlStringBuilder.toString().getBytes("UTF-8"));
			Document doc = builder.parse(input);
			doc.getDocumentElement().normalize();
			//System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			NodeList nList = doc.getElementsByTagName("entry");
			String dateInString;
			//LocalDate dt = null;
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				ListItem listItem = new ListItem();
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if(null!=eElement.getElementsByTagName("category") 
							&& null != eElement.getElementsByTagName("category").item(0)) {
						NamedNodeMap node1 = eElement.getElementsByTagName("category").item(0).getAttributes();
						Node namedNode=node1.getNamedItem("term");
						dateInString=namedNode.getNodeValue();
						listItem.setType(dateInString);
						
					}
					if(null!=eElement.getElementsByTagName("content") 
							&& null != eElement.getElementsByTagName("content").item(0)) {
						
						Node contentNode=eElement.getElementsByTagName("content").item(0);
						if(null !=contentNode && null !=contentNode.getFirstChild())
						{
						Node nodeElement=contentNode.getFirstChild();
						if(null != nodeElement){
							NodeList nodeList=nodeElement.getChildNodes();
							if(null != nodeList)
 {
									for (int temp1 = 0; temp1 < nodeList.getLength(); temp1++) 
									{
										Node nNode1 = nodeList.item(temp1);
										//d:Name d:Title
										if ("d:Name".equals(nNode1.getNodeName())) {
											listItem.setFileName(nNode1.getTextContent());
										}
										//d:ServerRelativeUrl d:FilePath
										if ("d:ServerRelativeUrl".equals(nNode1.getNodeName())) {
											listItem.setFilePath(nNode1.getTextContent());

										}
										//Release #2 - added - d:Created: Creation Date
										if ("d:TimeCreated".equals(nNode1.getNodeName())) {
											listItem.setCreationDt(nNode1.getTextContent());
										}
									}
								}
							}
						
						}
						listItemObj.add(listItem);
					}
				}
			}
		} catch (Exception e) {
		}
		return listItemObj;
	}
	/**
	 * This method is used to get the id for permission on folders.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	@Override
	public String getID(Map<String,String>map, String documentFolder)
			throws DocumentScaningException {
		String id = null;
		InputStream in = null;
		int responseCode = 0;
		String baseURL = "https://share.novartis.net/sites/mobiletmf-repository_dev/";
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			String url = messages.getString("baseurl") + messages.getString("idurl") + documentFolder + "')/listitemallfields/id";
				logger.info("inside getID URL::"+url);
			HttpResponse response = getHttpResponse(cookie, accessToken, url);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			logger.info("folderPermission  response code  " + responseCode);
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException("while getting response ,Response CODE: " + responseCode);
			}
			in = response.getEntity().getContent();

			try (BufferedReader buffer = new BufferedReader(new InputStreamReader(in))) {
				//String xml = buffer.readLine().collect(Collectors.joining("\n"));
				 StringBuilder xml = new StringBuilder();
			        String inputLine;

			        while ((inputLine = buffer.readLine()) != null) 
			            xml.append(inputLine);

			        in.close();
				final java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("<d:Id(.*?)[>](.*?)</d:Id>");
				final Matcher matcher = pattern.matcher(xml);
				if (matcher.find()) {
					id = matcher.group(2);
					logger.info("item id " + id);
				} else {
					logger.warning("item id not found");
				}

			}

		}

		catch (UnsupportedOperationException | IOException e) {
			logger.log(Level.SEVERE, "error getting ID  for permission ", e);
			throw new DocumentScaningException("error getting ID  for permission " + e.getMessage());
		} finally {
			if (null != in) {
				try {
					in.close();
				} catch (IOException e) {
					logger.log(Level.SEVERE, "error getting while closing inputstream ", e);
					throw new DocumentScaningException("error getting while closing inputstream " + e.getMessage());
				}
			}
		}

		return id;
	}

	/**
	 * This method is used to get the principalid for permission on folders.
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	@Override
	public String principalId(Map<String,String>map, String documentFolder,String user)
			throws DocumentScaningException {

		String principalId = null;
		InputStream in = null;
		int responseCode1 = 0;
		int responseCode2 = 0;
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			String url2;
			HttpClient client1 = HttpClientBuilder.create().build();
			HttpClient client2 = HttpClientBuilder.create().build();
			String userStr = "i%3A0%23.f%7Cmembership%7C" + user + "@novartis.net";
			String url1 = messages.getString("baseurl") + messages.getString("ensureuser") + userStr + "')";
			logger.info("inside ensureUser URL::"+url1);
			HttpPost httpPost = new HttpPost(url1);
			httpPost.setHeader("Authorization", accessToken);
			httpPost.setHeader("X-RequestDigest", formdgToken);
			httpPost.addHeader("Cookie", cookie);
			HttpResponse postResponse = client1.execute(httpPost);
			logger.info("inside ensureUser Response ::"+postResponse.getStatusLine().getStatusCode());
			if (null != postResponse && null != postResponse.getStatusLine()) {
				responseCode1 = postResponse.getStatusLine().getStatusCode();
			}
			
			if (responseCode1 == 200) {
				url2 = messages.getString("baseurl") + messages.getString("principalid") + userStr + "')";
			}else {
				userStr = "i%3A0%23.f%7Cmembership%7Csys_motion_madt@novartis.net";
				url2 = messages.getString("baseurl") + messages.getString("principalid") + userStr + "')";
			}
				
				logger.info("inside principalId URL::"+url2);
				HttpGet httpGet = new HttpGet(url2);
				httpGet.setHeader("Authorization", accessToken);
				httpGet.addHeader("Cookie", cookie);
				HttpResponse getResponse = client2.execute(httpGet);
				if (null != getResponse && null != getResponse.getStatusLine()) {
					responseCode2 = getResponse.getStatusLine().getStatusCode();
				}
				//logger.info("folderPermission  response code  " + responseCode);
				if (responseCode2 < 200 || responseCode2 > 300) {
					throw new DocumentScaningException("while getting response ,Response CODE: " + responseCode2);
				}
				if (null != getResponse && null != getResponse.getEntity()) {
					in = getResponse.getEntity().getContent();
					String inputLine;
					String xml=null;
					try (BufferedReader buffer = new BufferedReader(new InputStreamReader(in))) {
						  while ((inputLine = buffer.readLine()) != null)
				               xml += inputLine;

						final java.util.regex.Pattern pattern = java.util.regex.Pattern
								.compile("<d:Id(.*?)[>](.*?)</d:Id>");
						final Matcher matcher = pattern.matcher(xml);
						if (matcher.find()) {
							principalId = matcher.group(2);
							logger.info("principalId  " + principalId);
						} else {
							logger.info("principalId not Found");
						}

					}
				}
			
	

			
		} catch (UnsupportedOperationException | IOException e) {
			// TODO Auto-generated catch block
			logger.log(Level.SEVERE, "principalId : error while gettign principal ID ", e);
			throw new DocumentScaningException("error while gettign principal ID " + e.getMessage());
		} finally {
			if (null != in) {
				try {
					in.close();
				} catch (IOException e) {
					logger.log(Level.SEVERE, "principalId : error getting while closing inputstream ", e);
					throw new DocumentScaningException("error getting while closing inputstream " + e.getMessage());
				}
			}
		}
		return principalId;
	}
	 
	/**
	 * This mehtod is used to create the folders in share point site.
	 * @param map holding sharepoint conn params
	 * @param documentFolder folder to be created in sharepoint
	 * @param studyObj holding all details related to folder
	 * @param bw file writer to write error record.
	 * @throws DocumentScaningException
	 */
	@Override
	public void createFolder(Map<String,String>map, String documentFolder,MADTDSStudy studyObj,BufferedWriter bw)
			throws DocumentScaningException {
		try {
			//System.out.println("status:::3:"+result);
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			String url = messages.getString("baseurl") + messages.getString("createfolder") + documentFolder + "')";
			logger.info("inside createFolder url: "+url);
			HttpClient client = HttpClientBuilder.create().build();
			HttpPost post = new HttpPost(url);
			post.setHeader("Accept", "application/json");
			post.setHeader("Authorization", accessToken);
			post.setHeader("X-RequestDigest", formdgToken);
			post.setHeader("content-type", "application/json;odata=verbose");
			
			post.addHeader("Cookie", cookie);
			logger.info("url: " + url);
			HttpResponse response = client.execute(post);
			int httpStatus = 0;
			if (null != response && null != response.getStatusLine()) {
				httpStatus = response.getStatusLine().getStatusCode();
			}
			logger.info("create folder Response Code " + httpStatus);
			String responseMsg = EntityUtils.toString(response.getEntity(), "UTF-8");

			// If the returned HTTP response code is not in 200 series then
			// throw the error
			if (httpStatus < 200 || httpStatus > 300) {
				logger.info("studyObj==========>"+studyObj);
				logger.info("bw==========>"+bw);
				//Defect #2 - Writing to file incase if there is any exception
				if(null!=studyObj && null != bw) {
					bw.write("Folder Creation Failed::"+studyObj.getStudyId()+"/"+studyObj.getCountry()+"/"+studyObj.getSiteId()+"/"+studyObj.getCRAName());
					bw.newLine();
				}
				throw new DocumentScaningException("HTTP " + httpStatus + " - Error during create folder : " + responseMsg);
				
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while creating folder ", e);
			try {
				if(null!=studyObj && null != bw) {
					bw.write("Folder Creation Failed::"+studyObj.getStudyId()+"/"+studyObj.getCountry()+"/"+studyObj.getSiteId()+"/"+studyObj.getCRAName());
					bw.newLine();
				}
			}catch(Exception ex) {
				logger.log(Level.SEVERE, "error occured during error file writing ", ex);
			}
			logger.log(Level.SEVERE, "error while creating folder: ", e);
			throw new DocumentScaningException("error while creating folder" + e.getMessage());
		}

	}
	
	/**
	 * This method is used to recreate the permission on the folder which is having permission
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param documentFolder
	 * @throws DocumentScaningException
	 */
	@Override
	public void recreatePermission(Map<String,String>map,String itemId, String principalID, String documentFolder,String permission,MADTDSStudy studyObj, BufferedWriter bw)
			throws DocumentScaningException {
	
		int responseCode = 0;
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			String url = messages.getString("baseurl") + messages.getString("brokepermissionurl") 
			+ itemId + ")/breakroleinheritance(copyRoleAssignments=false,clearSubscopes=true)";
			logger.info("inside recreatePermission url..."+url);
			HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			logger.info("inside recreatePermission url..."+responseCode);
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException("recreatePermission : while getting response ,Response CODE: " + responseCode);
			}
			
			createFolderPermission(map, principalID, itemId, documentFolder,permission,false,studyObj,bw);

		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while recreatePermission ", e);
			throw new DocumentScaningException("error while recreatePermission " + e.getMessage());
		}
	}

/**
 * Releases #2 changes implemented- remove the access to all CRAs in case of completed and Cancelled trilas
 * @param map
 * @param itemId
 * @param principalID
 * @param documentFolder
 * @throws DocumentScaningException
 */
	@Override
	public void removePermission(Map<String,String>map,String itemId, String principalID, String documentFolder,MADTDSStudy studyObj,BufferedWriter bw)
			throws DocumentScaningException {
		logger.info("removePermission : started");
		int responseCode = 0;
		try {
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			String formdgToken=map.get("formDgToken");
			String url1 = messages.getString("baseurl") + messages.getString("brokepermissionurl") 
			+ itemId + ")/resetroleinheritance";
			HttpResponse response1 = postHttpResponse(cookie, accessToken, formdgToken, url1);
			logger.info(" resetroleinheritance response code..."+response1.getStatusLine().getStatusCode());
			String url = messages.getString("baseurl") + messages.getString("brokepermissionurl") 
			+ itemId + ")/breakroleinheritance(copyRoleAssignments=false,clearSubscopes=true)";
			logger.info("inside removePermission url..."+url);
			HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			logger.info("inside removePermission url..."+responseCode);
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException("removePermission : while getting response ,Response CODE: " + responseCode);
			}
			logger.info("MADT Study Object::"+studyObj.toString());
			if(null!=studyObj && null != bw) {
				bw.write("Audit::Folder permission Removed for ::"+studyObj.getStudyId()+"/"+studyObj.getCountry()+"/"+studyObj.getSiteId()+"/"+studyObj.getCRAName());
				bw.newLine();
			}
			
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while remove Permission ", e);
			throw new DocumentScaningException("error while removePermission " + e.getMessage());
		}
	}
	
	/**
	 * This method is used to give the permission on particullar person
	 * @param cookie
	 * @param accessToken
	 * @param formdgToken
	 * @param principalId
	 * @param itemId
	 * @param documentFolder
	 * @throws DocumentScaningException
	 */
	@Override
	public void createFolderPermission(Map<String,String>map, String principalId,
			String itemId, String documentFolder,String permission,boolean removeFlag,MADTDSStudy studyObj, BufferedWriter bw) throws DocumentScaningException {
	
		String cookie=map.get("cookies");
		String accessToken=map.get("accessToken");
		String formdgToken=map.get("formDgToken");
		logger.info("formdgToken  " + formdgToken);
		logger.info("principalId" + principalId);
		logger.info("itemId  " + itemId);
		int responseCode = 0;
		documentFolder = "Documents";
		try {
			if(removeFlag) {
				logger.info("createFolderPermission : removing folder permission");
				String url = messages.getString("baseurl") + messages.getString("folderpermission") + documentFolder + "')/items(" + itemId + ")/roleassignments/removeroleassignment(principalid="
						+ principalId + ",roledefid=" + permission + ")";
				logger.info("folderPermission removal url======>"+url);
				HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
				if (null != response && null != response.getStatusLine()) {
					responseCode = response.getStatusLine().getStatusCode();
				}
				logger.info("folderPermission  removal response code  " + responseCode);
				if (responseCode < 200 || responseCode > 300) {
					throw new DocumentScaningException("while getting response ,Response CODE: " + responseCode);
				}
				
				if(null!=studyObj && null != bw) {
					bw.write("Audit::Folder permission Removed for CRA::"+studyObj.getStudyId()+"/"+studyObj.getCountry()+"/"+studyObj.getSiteId()+"/"+studyObj.getCRAName());
					bw.newLine();
				}
			
			}else {
				logger.info("createFolderPermission : providing folder permission");
				String url = messages.getString("baseurl") + messages.getString("folderpermission") + documentFolder + "')/items(" + itemId + ")/roleassignments/addroleassignment(principalid="
						+ principalId + ",roledefid=" + permission + ")";
				logger.info("url======>"+url);
				HttpResponse response = postHttpResponse(cookie, accessToken, formdgToken, url);
				if (null != response && null != response.getStatusLine()) {
					responseCode = response.getStatusLine().getStatusCode();
				}
				logger.info("folderPermission  response code  " + responseCode);
				if (responseCode < 200 || responseCode > 300) {
					throw new DocumentScaningException("while getting response ,Response CODE: " + responseCode);
				}
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "createFolderPermission : error folder Permission", e);
			throw new DocumentScaningException("error folder Permission " + e.getMessage());
		}
	}
	/**
	 * This method is used to write the folder data to sharepoint
	 * @param map Map
	 * @param documentFolder String
	 * @param hmap Map
	 * @return responseCode int
	 * @throws DocumentScaningException
	 * _api/web/GetFileByServerRelativeUrl('/sites/docs/Email/TestFolder/testMail.msg')
	 */
	@Override
	public int createFolderList(Map<String,String>map, String documentFolder,MADTDSStudy studyObj,BufferedWriter bw)
			throws DocumentScaningException {
		logger.info("createFolderList");
		
		int responseCode = 0;
		try {
			//String[] CRAs = studyObj.getCRAList().toArray();
			/*Object[] array = (Object[])studyObj.getCRAList().toArray();
			String strCRA = Arrays.toString(array);
			System.out.println("strCRA::::"+strCRA);
			strCRA = strCRA.substring(1, strCRA.length()-1).trim();
			System.out.println("strCRA::::"+strCRA);*/
			String cookie=map.get("cookies");
			String accessToken=map.get("accessToken");
			
			String formdgToken=map.get("formDgToken");
			//String type=messages.getString("type");
			String StudyColumn=studyObj.getStudyId();
			String CountryColumn=studyObj.getCountry();
			String SiteColumn=studyObj.getSiteId();
			String strCRA = studyObj.getCRAName();
			String StatusColumn=studyObj.getStudyStatus();
			String FolderListItem=messages.getString("FolderListItem"); 
			String folderitems=messages.getString("folderitems"); 
			String endDate = studyObj.getSspEndDt();
			HttpClient client = HttpClientBuilder.create().build();
			System.out.println("file path "+documentFolder); 
			String url=messages.getString("baseurl") + messages.getString("getList")+folderitems+"')/items";
			logger.info("url-->"+url);
			HttpPost httpPost = new HttpPost(url);
			httpPost.setHeader("Authorization", accessToken);
			httpPost.addHeader("Cookie", cookie);
			httpPost.setHeader("X-RequestDigest", formdgToken);
			httpPost.setHeader("Content-Type", "application/json;odata=verbose");
			//httpPost.setHeader("X-HTTP-Method", "MERGE");
			httpPost.setHeader("IF-MATCH", "*");
			//Release #2 - Adding status column for color document being uploaded
			//String json = "{\"__metadata\" : {\"type\": \""+FolderListItem+"\"}, \"Title\": \"abcde\"}";
			String json = "{\"__metadata\" : {\"type\": \""+FolderListItem+"\"}, \"Study\": \""+StudyColumn+"\", \"Country\": \""+CountryColumn+"\", \"Site\": \""+SiteColumn+"\",\"EndDate\": \""+endDate+"\", \"CRA\": \""+strCRA+"\", \"Status\": \""+StatusColumn+"\"}";
			logger.info("json-->"+json);
			StringEntity entity = new StringEntity(json);
		    httpPost.setEntity(entity);
			HttpResponse response = client.execute(httpPost);
			if (null != response && null != response.getStatusLine()) {
				responseCode = response.getStatusLine().getStatusCode();
			}
			logger.info("update  response code  " + responseCode);
			if (responseCode < 200 || responseCode > 300) {
				throw new DocumentScaningException("while getting  update list to sharepoint response ,Response CODE: " + responseCode);
			}
			} catch (UnsupportedOperationException | IOException e) {
			logger.log(Level.SEVERE, "error while gettign update the status ", e);
			throw new DocumentScaningException("error while gettign update the status " + e.getMessage());
		}
		catch (Exception e) {
			logger.log(Level.SEVERE, "error while gettign update the status ", e);
			throw new DocumentScaningException("error while gettign update the status " + e.getMessage());
		}
		return responseCode;
	}
}