package com.novartis.madt.serviceimpl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.model.MADTDSStudy;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.service.MADTDocumentService;
import com.novartis.madt.util.PasswordEncUtil;
import com.novartis.madt.util.PdfConversion;

@Component
public class MADTSharePointServiceImpl implements MADTDocumentService {

	Logger logger = Logger.getLogger(MADTSharePointServiceImpl.class.getSimpleName());
	private String responseHTML = "";
	private int readTimeout = 20000;
	private String userAgent = "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.111 Safari/537.36";
	private ArrayList<String> cookieValue = new ArrayList<String>();
	private int responseCode;
	private String responseLocation = "";
	private ArrayList<String> postValue = new ArrayList<String>();
	private static final String PATTERN_SAML_TOKEN = "<input (.*) />";
	private static final String PATTERN_MS_FORM = "<input (.*)>";
	String webUrl = "https://share.novartis.net";
	String wreply = "https://login.microsoftonline.com/login.srf";
	String trustUrl = webUrl + "/_forms/default.aspx?apr=1&wa=wsignin1.0";
	String adfsHost = "https://sts.novartis.com";
	String adfsEndpoint = adfsHost + "/adfs/services/trust/2005/usernamemixed";
	private SharePointDocumntRepositoryImpl sharepointDocumentRespository = null;

	private PdfConversion pdfConversion = null;

	private ResourceBundle messages = null;

	public void setMessage(ResourceBundle messages) {
		this.messages = messages;
	}

	int count = 0;

	/**
	 * This method is used to process document from sharepoint
	 * 
	 * @param url - URL of the SharePoint Site e.g.
	 * @param url - URL of the SharePoint Site e.g.
	 * @param creationDt Document uploaded date
	 * @param documentFolder - document Folder path
	 * @param fileName - domain, can be null.
	 * @param messages ResourceBundle
	 * @param count
	 * @return
	 * @throws Exception
	 */

	@Override
	public String processDoucment(String creationDt,String documentFolder, String fileName, ResourceBundle message, int count)
			throws Exception {

		logger.info("start  of the method");
		String result = "";
		this.messages = message;
		Map<String, String> map = null;
		int checkoutStatus = 0;
		try {
			map = setUp();
			sharepointDocumentRespository = new SharePointDocumntRepositoryImpl();
			sharepointDocumentRespository.setMessage(message);
			checkoutStatus = sharepointDocumentRespository.checkout(map, fileName, documentFolder);
			/*
			 * if (checkoutStatus == 423) { //sharepointServices.discard(cookies, t,
			 * formDgToken, fileName, documentFolder); throw new
			 * DocumentScaningException("Document is already checkout, please try againg ");
			 * }
			 */
			result = "ConversionComplete";
			sharepointDocumentRespository.download(map, fileName, documentFolder);
			pdfConversion = new PdfConversion();
			pdfConversion.setMessage(message);
			//Release #2 Passing creationDt for adding as cutom property 
			Map<String,String> hmap = pdfConversion.pdfTopdf4bConversion(fileName,creationDt);
			String pdfFolder = "pdfoutput";
			sharepointDocumentRespository.upload(map, fileName, documentFolder,pdfFolder,false);
			Thread.sleep(30000);
			sharepointDocumentRespository.checkIn(map, fileName, documentFolder, result);
			
			//Release #2 - Code for uploading color document - start
		/*	logger.info("inside processDoucment : cFlag:"+hmap.get("cFlag"));
			if(hmap.get("cFlag").equals("true")) {
				pdfFolder = "pdfinput";
				String file_name = sharepointDocumentRespository.upload(map, fileName, documentFolder,pdfFolder,true);
				String status="Original Document";
				documentFolder = documentFolder+"/"+file_name;
				hmap.put("status", status);
				sharepointDocumentRespository.update(map, documentFolder, hmap);
				
			} //End*/
		} catch (Exception e) {
			count++;
			if (count <= 3) {
				processDoucment(creationDt,documentFolder, fileName, message, count);
			} else {
				result = "ConversionFailed";
				sharepointDocumentRespository.checkIn(map, fileName, documentFolder, result);
				logger.log(Level.WARNING, "error while document scanning ", e.getStackTrace());
			}
		}
		return result;
	}

	/**
	 * This method is used to get wctx for connecting sharepaoint
	 * 
	 * @return wctx token
	 * @throws Exception
	 */
	public String getWCTX() throws Exception {

		// generate the url for login.microsoft.com
		String ctxToken = "";
		BufferedReader inputStream = null;
		HttpsURLConnection connection = null;
		try {
			setResponseHTML("");
			String inputLine;
			StringBuffer response = new StringBuffer();
			URL url = new URL(null,
					"https://login.microsoftonline.com/login.srf?wa=wsignin1%2E0&wreply=https%3A%2F%2Fshare%2Enovartis%2Enet%2F%5Fforms%2Fdefault%2Easpx%3Fapr%3D1",
					new sun.net.www.protocol.https.Handler());

			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					InetSocketAddress.createUnresolved("useh-proxy.na.novartis.net", 2010));
			connection = (HttpsURLConnection) url.openConnection(proxy);
			connection.setReadTimeout(getReadTimeout());
			connection.setInstanceFollowRedirects(true);
			connection.setRequestMethod("GET");
			connection.setRequestProperty("User-Agent", getUserAgent());
			connection.setRequestProperty("Accept",
					"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
			connection.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
			connection.setRequestProperty("Connection", "keep-alive");
			if (getCookie().size() > 0) {
				connection.setRequestProperty("Cookie", getCookiesAsString());
			}

			setResponseCode(connection.getResponseCode());
			setResponseLocation(connection.getHeaderField("Location"));
			List<String> setCookie = connection.getHeaderFields().get("Set-Cookie");
			if (setCookie != null) {
				for (int i = 0; i < setCookie.size(); i++) {
					addCookie(setCookie.get(i));
				}
			}
			if (null != connection) {
				int responseCode = connection.getResponseCode();
				logger.info("wctx  response :  " + responseCode);
				if (responseCode < 200 || responseCode > 300) {
					throw new DocumentScaningException("error getting wctx token : " + responseCode);
				}
			}
			inputStream = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			while ((inputLine = inputStream.readLine()) != null) {
				response.append(inputLine);
			}
			setResponseHTML(response.toString());

			String searchString = "<input type=\"hidden\" name=\"ctx\" value=\"";
			searchString = "https://login.microsoftonline.com/common/reprocess?ctx=";
			int firstIndex = getResponseHTML().indexOf(searchString);
			//String endString = "\",\"urlSignUp\"";	sebin
			String endString = "\",\"urlCancel\"";
			int lastIndex = getResponseHTML().indexOf(endString);
			String ctxTokenTemp = getResponseHTML().substring(firstIndex, lastIndex);
			firstIndex = ctxTokenTemp.indexOf("ctx=");
			ctxToken = ctxTokenTemp.substring(firstIndex + 4);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while getting  wctx token", e);
			throw new DocumentScaningException("error while getting  wctx token" + e);
		} finally {
			if (null != inputStream)
				inputStream.close();
			if (null != connection) {
				connection.disconnect();
			}
		}

		return ctxToken;
	}

	/**
	 * Thid method is used to get Adfs token for connecting sharepoint
	 * 
	 * @param username
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public String getADFSToken(String username, String password) throws Exception {

		StringBuilder xmlString = new StringBuilder();
		xmlString.append("<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" ");
		xmlString.append(
				"xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"  ");
		xmlString.append("xmlns:saml=\"urn:oasis:names:tc:SAML:1.0:assertion\"  ");
		xmlString.append("xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\"  ");
		xmlString.append(
				"xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"  ");
		xmlString.append("xmlns:wsa=\"http://www.w3.org/2005/08/addressing\"  ");
		xmlString.append("xmlns:wssc=\"http://schemas.xmlsoap.org/ws/2005/02/sc\"  ");
		xmlString.append("xmlns:wst=\"http://schemas.xmlsoap.org/ws/2005/02/trust\"> ");
		xmlString.append("<s:Header> ");
		xmlString.append(
				"<wsa:Action s:mustUnderstand=\"1\">http://schemas.xmlsoap.org/ws/2005/02/trust/RST/Issue</wsa:Action> ");
		xmlString.append("<wsa:To s:mustUnderstand=\"1\">" + adfsEndpoint + "</wsa:To> ");
		xmlString.append("<wsa:MessageID>").append(UUID.randomUUID().toString()).append("</wsa:MessageID> ");
		xmlString.append(
				"<ps:AuthInfo xmlns:ps=\"http://schemas.microsoft.com/Passport/SoapServices/PPCRL\" Id=\"PPAuthInfo\"> ");
		xmlString.append("<ps:HostingApp>Medical Digital Platform</ps:HostingApp> ");
		xmlString.append("<ps:BinaryVersion>6</ps:BinaryVersion> ");
		xmlString.append("<ps:UIVersion>1</ps:UIVersion> ");
		xmlString.append("<ps:Cookies></ps:Cookies> ");
		xmlString.append("<ps:RequestParams>AQAAAAIAAABsYwQAAAAxMDMz</ps:RequestParams> ");
		xmlString.append("</ps:AuthInfo> ");
		xmlString.append("<wsse:Security> ");
		xmlString.append("<wsse:UsernameToken wsu:Id=\"user\"> ");
		xmlString.append("<wsse:Username>").append(username).append("</wsse:Username> ");
		xmlString.append("<wsse:Password>").append(password).append("</wsse:Password> ");
		xmlString.append("</wsse:UsernameToken> ");
		xmlString.append("<wsu:Timestamp Id=\"Timestamp\"> ");
		xmlString.append("<wsu:Created>" + getTimeString(0) + "</wsu:Created> ");
		xmlString.append("<wsu:Expires>" + getTimeString(10) + "</wsu:Expires> ");
		xmlString.append("</wsu:Timestamp> ");
		xmlString.append("</wsse:Security> ");
		xmlString.append("</s:Header> ");
		xmlString.append("<s:Body> ");
		xmlString.append("<wst:RequestSecurityToken Id=\"RST0\"> ");
		xmlString.append("<wst:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</wst:RequestType> ");
		xmlString.append("<wsp:AppliesTo> ");
		xmlString.append("<wsa:EndpointReference> ");
		xmlString.append("<wsa:Address>urn:federation:MicrosoftOnline</wsa:Address> ");
		xmlString.append("</wsa:EndpointReference> ");
		xmlString.append("</wsp:AppliesTo> ");
		xmlString.append("<wst:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</wst:KeyType> ");
		xmlString.append("</wst:RequestSecurityToken> ");
		xmlString.append("</s:Body> ");
		xmlString.append("</s:Envelope> ");
		BufferedReader inputStream = null;
		DataOutputStream wr = null;
		InputStreamReader isr = null;
		HttpsURLConnection connection = null;
		try {
			setResponseHTML("");
			String inputLine;
			StringBuffer response = new StringBuffer();

			URL url = new URL(null, adfsEndpoint, new sun.net.www.protocol.https.Handler());

			connection = (HttpsURLConnection) url.openConnection();
			connection.setReadTimeout(getReadTimeout());
			connection.setInstanceFollowRedirects(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8");
			if (getCookie().size() > 0) {
				connection.setRequestProperty("Cookie", getCookiesAsString());
			}
			clearPostValues();
			parsePostValues(PATTERN_SAML_TOKEN);
			// addPostValue(requestSecurityTokenFormat);
			addPostValue(xmlString.toString());
			// If method is POST then send POST values.
			connection.setDoOutput(true);

			wr = new DataOutputStream(connection.getOutputStream());
			 System.out.println( "Sending POST: " + getPostValuesAsString() );
			wr.writeBytes(getPostValuesAsString());
			wr.flush();

			// End
			if (null != connection) {
				int responseCode = connection.getResponseCode();
				logger.info("getADFSToken  response code  " + responseCode);
				if (responseCode < 200 || responseCode > 300) {
				//sebin throw new DocumentScaningException("adfs token code  :   " + responseCode); //sebin	
				}
			}
			setResponseCode(connection.getResponseCode());
			setResponseLocation(connection.getHeaderField("Location"));
			List<String> setCookie = connection.getHeaderFields().get("Set-Cookie");
			if (setCookie != null) {
				for (int i = 0; i < setCookie.size(); i++) {
					addCookie(setCookie.get(i));
				}
			}

			/////

			//isr = new InputStreamReader(connection.getErrorStream());
			//inputStream = new BufferedReader(isr);
			/////
			
			isr = new InputStreamReader(connection.getInputStream());
			inputStream = new BufferedReader(isr);
			
			//
			while ((inputLine = inputStream.readLine()) != null) {
				response.append(inputLine);
			}
			
			System.out.println("response.toString():::"+response.toString());
			
			setResponseHTML(response.toString());

		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while getting AdfsToken", e);
			throw new DocumentScaningException("error while getting AdfsToken" + e);
		} finally {
			if (null != inputStream)
				inputStream.close();
			if (null != wr)
				wr.close();
			if (null != isr) {
				isr.close();
			}
			if (null != connection) {
				connection.disconnect();
			}
		}
		return getResponseHTML();
	}

	/**
	 * This method is used to get adfsparam for connectiong sharepoint
	 * 
	 * @param wctx
	 * @param adfsToken
	 * @return
	 * @throws Exception
	 */
	public String getADFSTParam(String wctx, String adfsToken) throws Exception {

		String reqParam = "wa=wsignin1.0&wctx=" + URLEncoder.encode(wctx) + "&wresult=" + URLEncoder.encode(adfsToken);
		String t = "";
		DataOutputStream wr = null;
		BufferedReader inputStream = null;
		HttpsURLConnection connection = null;
		InputStreamReader isr = null;
		try {
			setResponseHTML("");
			String inputLine;
			StringBuffer response = new StringBuffer();

			URL url = new URL(null, wreply, new sun.net.www.protocol.https.Handler());
			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					InetSocketAddress.createUnresolved("useh-proxy.na.novartis.net", 2010));
			connection = (HttpsURLConnection) url.openConnection(proxy);
			connection.setReadTimeout(getReadTimeout());
			connection.setInstanceFollowRedirects(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			if (getCookie().size() > 0) {
				connection.setRequestProperty("Cookie", getCookiesAsString());
			}
			clearPostValues();
			parsePostValues(PATTERN_SAML_TOKEN);
			addPostValue(reqParam);
			// If method is POST then send POST values.
			connection.setDoOutput(true);
			wr = new DataOutputStream(connection.getOutputStream());
			wr.writeBytes(getPostValuesAsString());
			wr.flush();

			// End
			if (null != connection) {
				int responseCode = connection.getResponseCode();
				logger.info("getADFSTParam  response code  " + responseCode);
				if (responseCode < 200 || responseCode > 300) {
					throw new DocumentScaningException("while getting response ,Response CODE: " + responseCode);
				}
			}
			setResponseCode(connection.getResponseCode());
			setResponseLocation(connection.getHeaderField("Location"));
			List<String> setCookie = connection.getHeaderFields().get("Set-Cookie");
			if (setCookie != null) {
				for (int i = 0; i < setCookie.size(); i++) {
					addCookie(setCookie.get(i));
				}
			}
			logger.info("adfctParam code : " + getResponseCode());
			isr = new InputStreamReader(connection.getInputStream());
			inputStream = new BufferedReader(isr);
			while ((inputLine = inputStream.readLine()) != null) {
				response.append(inputLine);
			}
			setResponseHTML(response.toString());
			// logger.info("ADFS call Response - " + getResponseHTML());

			String searchString = "id=\"t\" value=\"";
			int firstIndex = getResponseHTML().indexOf(searchString);
			int lastIndex = getResponseHTML().lastIndexOf("\">");
			t = getResponseHTML().substring(firstIndex + 14, lastIndex);

		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while getting adfctParam ", e);
			throw new DocumentScaningException("error while getting adfctParam " + e);
		} finally {
			if (null != inputStream)
				inputStream.close();
			if (null != wr)
				wr.close();
			if (null != isr)
				isr.close();
			if (null != connection) {
				connection.disconnect();
			}
		}
		return t;
	}

	/**
	 * this mehotd is used to authenticate for sharepoint site.
	 * 
	 * @param t
	 * @return
	 * @throws Exception
	 */
	public String getFedAuth(String t) throws Exception {

		String token = "t=" + URLEncoder.encode(t);
		BufferedReader inputStream = null;
		DataOutputStream wr = null;
		HttpsURLConnection connection = null;
		InputStreamReader isr = null;
		try {
			setResponseHTML("");
			String inputLine;
			StringBuffer response = new StringBuffer();

			URL url = new URL(null, trustUrl, new sun.net.www.protocol.https.Handler());
			Proxy proxy = new Proxy(Proxy.Type.HTTP,
					InetSocketAddress.createUnresolved("useh-proxy.na.novartis.net", 2010));
			connection = (HttpsURLConnection) url.openConnection(proxy);
			connection.setReadTimeout(getReadTimeout());
			connection.setInstanceFollowRedirects(false);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			if (getCookie().size() > 0) {
				connection.setRequestProperty("Cookie", getCookiesAsString());
			}
			clearPostValues();
			parsePostValues(PATTERN_MS_FORM);
			clearCookies();
			addPostValue(token);
			// If method is POST then send POST values.
			connection.setDoOutput(true);
			wr = new DataOutputStream(connection.getOutputStream());
			// System.out.println( "Sending POST: " + getPostValuesAsString() );
			wr.writeBytes(getPostValuesAsString());
			wr.flush();
			// End
			if (null != connection) {
				int responseCode = connection.getResponseCode();
				logger.info("getFedAuth  response code  " + responseCode);

			}
			setResponseCode(connection.getResponseCode());
			setResponseLocation(connection.getHeaderField("Location"));
			List<String> setCookie = connection.getHeaderFields().get("Set-Cookie");
			if (setCookie != null) {
				for (int i = 0; i < setCookie.size(); i++) {
					addCookie(setCookie.get(i));
				}
			}
			logger.info("getFedAuth - " + getResponseCode());
			isr = new InputStreamReader(connection.getInputStream());
			inputStream = new BufferedReader(isr);
			while ((inputLine = inputStream.readLine()) != null) {
				response.append(inputLine);
			}
			setResponseHTML(response.toString());
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while getting  FedAuth  ", e);
			throw new DocumentScaningException("error while getting  FedAuth " + e);
		} finally {
			if (null != inputStream)
				inputStream.close();
			if (null != wr)
				wr.close();
			if (null != isr)
				isr.close();
			if (null != connection) {
				connection.disconnect();
			}
		}
		return getCookiesAsString();
	}

	public String getFormDigest(String cookie) throws DocumentScaningException {
		try {
			HttpClient client = HttpClientBuilder.create().build();
			String baseurl = messages.getString("baseurl");
			HttpPost post = new HttpPost(baseurl + "_api/contextinfo");
			post.setHeader("Accept", "application/json; odata=verbose");
			post.setHeader("content-type", "application/json; odata=verbose");

			post.addHeader("Cookie", cookie);

			HttpResponse response = client.execute(post);
			int httpStatus = 0;
			if (null != response && null != response.getStatusLine()) {
				httpStatus = response.getStatusLine().getStatusCode();
			}
			logger.info("get FormDigest Response code" + httpStatus);
			if (httpStatus < 200 || httpStatus > 300) {
				throw new DocumentScaningException("while getting response ,Response CODE: " + httpStatus);
			}
			String responseMsg = EntityUtils.toString(response.getEntity(), "UTF-8");
			String frmDigestTk = responseMsg
					.substring(responseMsg.indexOf("\"FormDigestValue\":") + "\"FormDigestValue\":".length());
			frmDigestTk = frmDigestTk.substring(frmDigestTk.indexOf("\"") + 1);
			frmDigestTk = frmDigestTk.substring(0, frmDigestTk.indexOf("\""));
			// frmDigestTk = frmDigestTk.substring(0,frmDigestTk.indexOf(","));
			return frmDigestTk;

		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while getting formDigesttoken", e);
			throw new DocumentScaningException("error while getting formDigesttoken" + e);
		}

	}

	private String getResponseHTML() {
		if (responseHTML == null) {
			responseHTML = "";
		}
		return responseHTML;
	}

	private void setResponseHTML(String responseHTML) {
		this.responseHTML = responseHTML;
	}

	public String getCookiesAsString() {
		String cookieValue = "";
		if (getCookie() != null) {
			for (int i = 0; i < getCookie().size(); i++) {
				cookieValue += "; " + getCookie().get(i).substring(0, getCookie().get(i).indexOf(";"));
			}
		}
		if (cookieValue.length() > 0) {
			cookieValue = cookieValue.substring(2);
		}
		return cookieValue;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseLocation() {
		return responseLocation;
	}

	public void setResponseLocation(String responseLocation) {
		this.responseLocation = responseLocation;
	}

	public ArrayList<String> getCookie() {
		return cookieValue;
	}

	public void setCookie(ArrayList<String> cookieValue) {
		this.cookieValue = cookieValue;
	}

	private void addCookie(String cookieToAdd) {
		cookieValue.add(cookieToAdd);
	}

	private void clearCookies() {
		cookieValue.clear();
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}

	private void parsePostValues(String pattern) {
		// TODO:
		// Test net Pattern
		Pattern p1 = Pattern.compile(pattern);
		Matcher m1 = p1.matcher(getResponseHTML());
		while (m1.find()) {
			Pattern p2 = Pattern.compile("name=\"([^\"]+)\"(.*?)value=\"([^\"]+)\"");
			Matcher m2 = p2.matcher(m1.group(0));
			while (m2.find()) {
				String v = m2.group(3);
				v = v.replace("&lt;", "<");
				v = v.replace("&gt;", ">");
				v = v.replace("&quot;", "\"");
				v = v.replace("&amp;", "&");
				try {
					addPostValue(m2.group(1) + "=" + URLEncoder.encode(v, "UTF-8"));
				} catch (UnsupportedEncodingException e) {
				}
			}
		}
	}

	private void clearPostValues() {
		postValue.clear();
	}

	private String getPostValuesAsString() {
		String r = "";
		for (int i = 0; i < postValue.size(); i++) {
			r += "&" + postValue.get(i);
		}
		if (r.length() > 0) {
			r = r.substring(1);
		}
		//System.out.println("getPostValuesAsString::"+r);
		return r;
	}

	private void addPostValue(String postValueToAdd) {
		postValue.add(postValueToAdd);
	}

	private String getTimeString(int minutesInFuture) {
		Calendar rightNow = Calendar.getInstance();
		rightNow.add(Calendar.SECOND,
				(((rightNow.get(Calendar.ZONE_OFFSET) + (rightNow.get(Calendar.DST_OFFSET))) / -1000)));
		rightNow.add(Calendar.MINUTE, minutesInFuture);
		String timeString = String.format("%d-%02d-%02dT%02d:%02d:%02d.0000000Z", rightNow.get(Calendar.YEAR),
				(rightNow.get(Calendar.MONTH) + 1), rightNow.get(Calendar.DATE), rightNow.get(Calendar.HOUR_OF_DAY),
				rightNow.get(Calendar.MINUTE), rightNow.get(Calendar.SECOND));
		return timeString;
	}

	/**
	 * This method is used to connect sharepoint
	 * 
	 * @param arg
	 * @throws Exception
	 */
	public Map setUp() throws Exception {
		Map<String, String> map = new HashMap<>();
		try {
			logger.info("setUp : Start");
			String wctx = getWCTX();
			String userName = messages.getString("sp_userName");
			String password = messages.getString("sp_pasword");
			String decPWD = PasswordEncUtil.convert("d", password);
			//System.out.println(decPWD);
			String adfsToken = getADFSToken(userName, decPWD);
			String t = getADFSTParam(wctx, adfsToken);
			String cookies = getFedAuth(t);
			String formDgToken = getFormDigest(cookies);
			map = new HashMap<>();
			map.put("accessToken", t);
			map.put("cookies", cookies);
			map.put("formDgToken", formDgToken);
			logger.info("setUp : End");
		} catch (DocumentScaningException e) {
			logger.log(Level.SEVERE, "error while connecting sharepoint", e);
			
			throw new DocumentScaningException("error while connecting  sharepoint " + e);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while connecting sharepoint", e);
			throw new DocumentScaningException("error while connecting  sharepoint " + e);
		}
		return map;
	}

	/**
	 * Defect #2 - This method is used to connect sharepoint and logging the error to file.
	 * 
	 * @param documentFolder
	 * @param studyObj passed this to print to file incase of connection failure
	 * @param bw file write object
	 * @return
	 * @throws Exception
	 */
	public Map setUp(String documentFolder, MADTDSStudy studyObj, BufferedWriter bw) throws Exception {
		Map<String, String> map = new HashMap<>();
		try {
			logger.info("setUp :: studyObj==========>" + studyObj.toString());
			String wctx = getWCTX();
			String userName = messages.getString("sp_userName");
			String password = messages.getString("sp_pasword");
			String decPWD = PasswordEncUtil.convert("d", password);
			//System.out.println("decPWD===>"+decPWD);
			String adfsToken = getADFSToken(userName, decPWD);
			String t = getADFSTParam(wctx, adfsToken);
			String cookies = getFedAuth(t);
			String formDgToken = getFormDigest(cookies);
			map = new HashMap<>();
			map.put("accessToken", t);
			map.put("cookies", cookies);
			map.put("formDgToken", formDgToken);
		} catch (DocumentScaningException e) {
			logger.log(Level.SEVERE, "error while connecting sharepoint during folder creation of -->" + documentFolder,
					e);
			//Defect #2 - Writing to file incase if there is any exception.
			bw.write("Sharepoint connection failed::" + studyObj.getStudyId() + "/" + studyObj.getCountry() + "/"
					+ studyObj.getSiteId() + "/" + studyObj.getCRAName());
			bw.newLine();
			throw new DocumentScaningException("error while connecting  sharepoint " + e);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error while connecting sharepoint", e);
			throw new DocumentScaningException("error while connecting  sharepoint " + e);

		}
		return map;
	}
}