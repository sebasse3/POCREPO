package com.novartis.madt.service;

import java.util.Map;
import java.util.ResourceBundle;

/**
 * 
 * @author medidsu1
 *
 */
public interface MADTDocumentService {
	/**
	 * This method is used to process document 
	 * @param creationDt
	 * @param documentFolder
	 * @param fileName
	 * @param map
	 * @param message
	 * @param count
	 * @return
	 * @throws Exception
	 */
	public String processDoucment(String creationDt,String documentFolder, String fileName,
			ResourceBundle message,int count) throws Exception;
}
