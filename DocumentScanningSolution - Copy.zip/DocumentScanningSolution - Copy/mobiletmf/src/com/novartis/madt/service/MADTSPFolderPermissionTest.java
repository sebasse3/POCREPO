package com.novartis.madt.service;

import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.util.PasswordEncUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MADTSPFolderPermissionTest {

	SharePointDocumntRepositoryImpl madtAccessService = null;
	MADTSharePointServiceImpl authServiceImpl = null;
	String wctx = null;
	String adfsToken = null;
	String t = null;
	String cookies = null;
	String formDgToken = null;
	ResourceBundle messages = null;
	Map<String, String> map = new HashMap<String, String>();
	String id = "";
	String principalId = "";
	String user = "SYS_MOTION_MADT@novartis.net";
	String permission = "1073741826";
	@Before
	public void setUp() throws Exception {
		messages = ResourceBundle.getBundle("config");
		madtAccessService = new SharePointDocumntRepositoryImpl();
		madtAccessService.setMessage(messages);
		authServiceImpl = new MADTSharePointServiceImpl();
		authServiceImpl.setMessage(messages);
		wctx = authServiceImpl.getWCTX();
		String sp_userName = "SYS_MOTION_MADT@novartis.net";
		String sp_pasword = "9GrlfeZTfKSuVIR9Y5+nbQ==";
		String decPWD = PasswordEncUtil.convert("d", sp_pasword);
		adfsToken = authServiceImpl.getADFSToken(sp_userName, decPWD);
		t = authServiceImpl.getADFSTParam(wctx, adfsToken);
		cookies = authServiceImpl.getFedAuth(t);
		formDgToken = authServiceImpl.getFormDigest(cookies);
		map.put("cookies", cookies);
		map.put("accessToken", t);
		map.put("formDgToken", formDgToken);
		
	}
	/**
	 * Test the folder permission
	 */
	@Test
	public void testDBrokePermission() {
		boolean isTrue = true;
		String documentFolder = "Shared%20Documents/Test123";
		try {
			id = madtAccessService.getID(map, documentFolder);
			principalId = madtAccessService.principalId(map, documentFolder, user);
			madtAccessService.recreatePermission(map, id,principalId, documentFolder, permission,null,null);
		} catch (DocumentScaningException e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	@After
	public void tearDown() throws Exception {
	}
}
