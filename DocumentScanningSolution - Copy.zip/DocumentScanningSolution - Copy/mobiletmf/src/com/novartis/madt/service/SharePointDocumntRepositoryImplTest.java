package com.novartis.madt.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.util.PasswordEncUtil;
import com.novartis.madt.util.PdfConversion;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SharePointDocumntRepositoryImplTest {

	SharePointDocumntRepositoryImpl madtAccessService = null;
	MADTSharePointServiceImpl authServiceImpl = null;
	String wctx = null;
	String adfsToken = null;
	String t = null;
	String cookies = null;
	String formDgToken = null;
	ResourceBundle messages = null;
	Map<String, String> map = new HashMap<String, String>();
	String fileName = "Test.pdf";
	String documentFolder = "Shared%20Documents/Test123";
	PdfConversion pdfConversion = null;

	/**
	 * Initial Setup for all test cases
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		messages = ResourceBundle.getBundle("config");
		madtAccessService = new SharePointDocumntRepositoryImpl();
		madtAccessService.setMessage(messages);
		authServiceImpl = new MADTSharePointServiceImpl();
		authServiceImpl.setMessage(messages);
		pdfConversion = new PdfConversion();
		pdfConversion.setMessage(messages);
		wctx = authServiceImpl.getWCTX();
		String sp_userName = "SYS_MOTION_MADT@novartis.net";
		String sp_pasword = "kmCFrEEgmW9bQqKvVvtRAA==";
		String decPWD = PasswordEncUtil.convert("d", sp_pasword);
		adfsToken = authServiceImpl.getADFSToken(sp_userName, decPWD);
		t = authServiceImpl.getADFSTParam(wctx, adfsToken);
		cookies = authServiceImpl.getFedAuth(t);
		formDgToken = authServiceImpl.getFormDigest(cookies);
		map.put("cookies", cookies);
		map.put("accessToken", t);
		map.put("formDgToken", formDgToken);
	}

	/**
	 * Test the document checkout
	 */
	@Test
	public void testACheckout() {

		boolean isTrue = true;
		try {
			madtAccessService.checkout(map, fileName, documentFolder);
		} catch (DocumentScaningException e) {
			isTrue = false;
		}

		Assert.assertTrue(isTrue);
	}

	/**
	 * Test the document Download
	 */
	@Test
	public void testBDownload() {

		boolean isTrue = true;
		try {
			madtAccessService.download(map, fileName, documentFolder);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	/*
	 * test the PDF Document conversion to grey scale and version upgrade if
	 * required.
	 */
	@Test
	public void testCPDFConv() {

		boolean isTrue = true;
		String dateTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault()).format(new Date());
		try {
			pdfConversion.pdfTopdf4bConversion(fileName,dateTime);
		} catch (DocumentScaningException e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	/**
	 * Test the Document upload
	 */
	@Test
	public void testDUpload() {

		boolean isTrue = true;
		String pdfFolder="C:\\Srini\\pdfinput";
		String dateTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault()).format(new Date());
		try {
			madtAccessService.upload(map, fileName, documentFolder,pdfFolder,true);
		} catch (DocumentScaningException e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	/**
	 * Test the Document Checkin
	 */
	@Test
	public void testECheckin() {
		boolean isTrue = true;
		try {
			madtAccessService.checkIn(map, fileName, documentFolder, "");
		} catch (DocumentScaningException e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	/*
	 * @Test public void testFDiscard() {
	 * 
	 * boolean isTrue = true; try { madtAccessService.discard(map, fileName,
	 * documentFolder); } catch (DocumentScaningException e) { // TODO
	 * Auto-generated catch block isTrue = true; } Assert.assertTrue(isTrue);
	 * 
	 * }
	 */

}
