package com.novartis.madt.service;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.novartis.madt.batch.MADTDocumentConversionBatchJob;
import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.model.ListItem;
import com.novartis.madt.repository.DocumentRepository;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.util.PasswordEncUtil;

public class MADTSPFolderCreationTest {

	SharePointDocumntRepositoryImpl madtAccessService = null;
	MADTSharePointServiceImpl authServiceImpl = null;
	String wctx = null;
	String adfsToken = null;
	String t = null;
	String cookies = null;
	String formDgToken = null;
	ResourceBundle messages = null;
	Map<String, String> map = new HashMap<String, String>();
	String id = "40";
	String principalId = "137";
	/**
	 * Initial Setup
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		messages = ResourceBundle.getBundle("config");
		madtAccessService = new SharePointDocumntRepositoryImpl();
		madtAccessService.setMessage(messages);
		authServiceImpl = new MADTSharePointServiceImpl();
		authServiceImpl.setMessage(messages);
		wctx = authServiceImpl.getWCTX();
		String sp_userName = "SYS_MOTION_MADT@novartis.net";
		String sp_pasword = "9GrlfeZTfKSuVIR9Y5+nbQ==";
		String decPWD = PasswordEncUtil.convert("d", sp_pasword);
		adfsToken = authServiceImpl.getADFSToken(sp_userName, decPWD);
		t = authServiceImpl.getADFSTParam(wctx, adfsToken);
		cookies = authServiceImpl.getFedAuth(t);
		formDgToken = authServiceImpl.getFormDigest(cookies);
		map.put("cookies", cookies);
		map.put("accessToken", t);
		map.put("formDgToken", formDgToken);
	}
	/**
	 * Test the folder creation
	 */
	@Test
	public void testCFolderPermission() {
		boolean isTrue = true;
		String documentFolder = "Shared%20Documents";
		documentFolder += "/Test123";
		try {
			madtAccessService.createFolder(map, documentFolder,null,null);
		} catch (DocumentScaningException e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	@After
	public void tearDown() throws Exception {

	}

}
