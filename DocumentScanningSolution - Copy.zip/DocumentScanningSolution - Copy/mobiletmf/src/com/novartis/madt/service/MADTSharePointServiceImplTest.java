package com.novartis.madt.service;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;

public class MADTSharePointServiceImplTest {
	MADTSharePointServiceImpl spauthService = null;
	ResourceBundle messages = null;

	/**
	 * Initial setup for test case
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		spauthService = new MADTSharePointServiceImpl();
		FileInputStream fis = null;
		messages = ResourceBundle.getBundle("config");

	}

	/**
	 * Test the process document which includes Sharepoint Authentication,Checkout,
	 * Download,Conversion,Upload and Check in the document.
	 */
	@Test
	public void testProcessDoucment() {
		Map<String, String> map = new HashMap<>();
		String fileName = "Test.pdf";
		String documentFolder = "Shared%20Documents/Test123";
		String dateTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.getDefault()).format(new Date());
		boolean isTrue = true;
		try {
			spauthService.processDoucment(dateTime,documentFolder, fileName, messages, 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	@After
	public void tearDown() throws Exception {
	}

}
