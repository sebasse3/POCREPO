package com.novartis.madt.service;

import java.util.ResourceBundle;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.novartis.madt.batch.MADTFolderCreationBatchJob;
import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.util.PasswordEncUtil;

/**
 * 
 * @author SANKUSR2
 * 
 */
public class MADTGetFolderDetailsTest {

	MADTFolderCreationBatchJob fc = null;
	String base_path_api = "";
	String impact_userName = "";
	String impact_password = "";
	String keyCode = "";
	ResourceBundle messages = null;

	/**
	 * Initial Setup
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		messages = ResourceBundle.getBundle("config");
		fc = new MADTFolderCreationBatchJob();
		base_path_api = "https://apigweu-dev.eu.novartis.net/api/1.0/pharma/ctms/dv12n/DocumentScan";
		impact_userName = "SYS_MOBILETMF_INT";
		impact_password = "kNwNqPemHZatPYiRR3nFVQ==";
		keyCode = "7eb82fc6-3e9d-411e-8ba1-70cbfdf368ee";

	}

	/**
	 * Test the impact site connection and able to fetching data
	 */
	@Test
	public void testGetDataFromImpactSite() {
		boolean isTrue = true;

		try {
			String decPWD = PasswordEncUtil.convert("d", impact_password);
			fc.getDataFromImpactSite(base_path_api, impact_userName, decPWD,keyCode);
		/*} catch (DocumentScaningException e) {
			// TODO Auto-generated catch block
			isTrue = false;*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			isTrue = false;
		}
		Assert.assertTrue(isTrue);
	}

	@After
	public void tearDown() throws Exception {

	}

}
