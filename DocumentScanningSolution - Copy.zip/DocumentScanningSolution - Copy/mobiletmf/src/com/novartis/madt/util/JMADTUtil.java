package com.novartis.madt.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import com.novartis.madt.constants.JMADTConstants;

public class JMADTUtil {
	static Logger logger = Logger.getLogger(JMADTUtil.class.getSimpleName());
	/**
	 * 
	 * @param indate
	 * @return
	 */
	public static String convertStringToDate(Date indate) {
		String dateString = null;
		SimpleDateFormat sdfr = new SimpleDateFormat("yyyy-MM-dd");
		try {
			dateString = sdfr.format(indate);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return dateString;
	}
/**
 * 
 * @param indate
 * @return
 */
	public static String convertToDateMinus3(String indate) {
		Date outDate = null;
		String resultDt = null;
		DateFormat outFormat = new SimpleDateFormat( "yyyy-MM-dd");
		try {
			outDate = outFormat.parse(indate);
			logger.fine("outDate====>"+outDate);
			Calendar c = Calendar.getInstance(); 
			c.setTime(outDate); 
			c.add(Calendar.MONTH, -3);
			outDate =  c.getTime();
			resultDt = outFormat.format(outDate);
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return resultDt;
	}
	/**
	 * 
	 * @param indate
	 * @return
	 */
	public static boolean validateDate(String indate) {
		boolean isDate = true;
		try {
			SimpleDateFormat sdfr = new SimpleDateFormat("yyyy-MM-dd");
			sdfr.setLenient(false);
			Date dt = sdfr.parse(indate);

		} catch (ParseException e) {
			isDate = false;
		}
		return isDate;
	}

	/**
	 * 
	 * @param startDate
	 * @param EndDate
	 * @return
	 */
	public static boolean validateDate(String startDate, String EndDate) {
		boolean isValidDate = true;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date1 = sdf.parse(startDate);
			Date date2 = sdf.parse(EndDate);
			if (date2.equals(date1) || date2.after(date1)) {
				System.out.println("inside if");
				isValidDate = false;
			}
		} catch (ParseException e) {
			isValidDate = true;
		}
		return isValidDate;
	}

	/**
	 * 
	 */
	public static void loadLogerFile() {
		InputStream is = null;
		try {
			is = new FileInputStream(JMADTConstants.BASE_PATH + "javalogging.properties");
			LogManager.getLogManager().readConfiguration(is);
		}

		catch (Exception e) {
			if (null != is) {
				try {
					is.close();
				} catch (IOException e1) {

				}
			}
		}
	}
}
