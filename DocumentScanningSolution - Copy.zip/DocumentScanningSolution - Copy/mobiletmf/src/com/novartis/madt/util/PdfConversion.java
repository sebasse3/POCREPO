package com.novartis.madt.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.aspose.pdf.ConvertErrorAction;
import com.aspose.pdf.Document;
import com.aspose.pdf.DocumentInfo;
import com.aspose.pdf.Page;
import com.aspose.pdf.PdfFormat;
import com.novartis.madt.exception.DocumentScaningException;

/**
 * 
 * @author SANKUSR2
 *
 */
public class PdfConversion {
	static Logger logger = Logger.getLogger(PdfConversion.class.getSimpleName());

	private ResourceBundle messages;

	public void setMessage(ResourceBundle messages) {
		this.messages = messages;
	}

	/**
	 * Converson of PDF Grey Scale and PDF 1.4 Version for lower versions.
	 * 
	 * @throws DocumentScaningException
	 */
	public Map<String,String> pdfTopdf4bConversion(String fileName,String createdDt) throws DocumentScaningException {
		//String cFlag = "false";
		Map<String,String> hm = new HashMap<String,String>();
		try {
			logger.fine("pdf conversion started fileName-->" + fileName+"::createdDt-->"+createdDt);
			LoadAsposeLicence();
			String basePath = messages.getString("basepath");
			String downloadPath =  basePath + messages.getString("pdfinput");
			Document doc = new Document(downloadPath + fileName);
			DocumentInfo metaInfo1 = doc.getInfo();
			com.aspose.pdf.RgbToDeviceGrayConversionStrategy strategy = new com.aspose.pdf.RgbToDeviceGrayConversionStrategy();
			//Release #2 - Change - Adding custom property and creating original doc- start
			//Thread.sleep(10000); // waiting till document downloads.

			//Document doc2 = new Document(downloadPath + fileName);
			//DocumentInfo metaInfo1 = doc.getInfo();
			double version2 = Double.parseDouble(doc.getVersion());
			logger.fine("Upgrading version for original document"+version2);
			if (version2 < 1.4) { // Check for document version and upgrade to 1.4 if it is lower version
				doc.convert(downloadPath + fileName, PdfFormat.v_1_4, ConvertErrorAction.Delete);
				logger.info("Version upgraded from -->" + version2);
			}
			//String file_name = fileName.substring(0, fileName.lastIndexOf('.'));
			//file_name = file_name+"_Original.pdf";
			//metaInfo.addItem("Scan Date Time", createdDt);
			//doc.save(downloadPath + file_name); // adding scan date in the original document				
			for (int idxPage = 1; idxPage <= doc.getPages().size(); idxPage++) {
				Page page = doc.getPages().get_Item(idxPage);
				//Release #2 -Change Checking document type
				/*if(page.getColorType() == 0) {
					cFlag = "true";					
				}*/
				strategy.convert(page);
			}
			String uploadPath =  basePath + messages.getString("pdfoutput");
			//Release #2 -Change - Adding createdDt to document as custom property 
			//hm.put("cFlag", cFlag);
			metaInfo1.addItem("Scan Date Time", createdDt); // adding scanned date in the Converted document
			com.aspose.pdf.Document.OptimizationOptions opt = new Document.OptimizationOptions();
			//Optimizing to restict the pdf size.
			opt.setRemoveUnusedObjects(true);
			opt.setRemoveUnusedStreams(true);
			opt.setLinkDuplcateStreams(true);
			opt.setCompressImages(true);
			
			doc.optimizeResources(opt);
			doc.save(uploadPath + fileName);
			logger.info("conversion is done  " + fileName);
		} catch (Exception exception) {
			logger.log(Level.SEVERE, "error while pdf conversion ", exception);
			throw new DocumentScaningException("error while pdf conversion " + exception.getMessage());
		}
		return hm;
	}
	/**
	 * This method is used to load aspose licence.
	 */
	public  void LoadAsposeLicence()
	{
		InputStream in = null;
		try {
			String basePath = messages.getString("basepath");
			String filename = messages.getString("aspose_file_name");
			in = new FileInputStream(basePath+filename);
			com.aspose.pdf.License license = new com.aspose.pdf.License();
			license.setLicense(in);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "error getting while closing inputstream ", e);

		} finally {
			if (null != in) {
				try {
					in.close();
				} catch (IOException e) {

					logger.log(Level.SEVERE, "error getting while closing inputstream ", e);
				}

			}
		}
	}
}
