package com.novartis.madt.util;

import java.util.logging.Logger;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * This class is used to Encrypt and decrypt the password
 * 
 * @author sankusr2
 *
 */
public class PasswordEncUtil {
	static private final Logger fLogger = Logger.getLogger("com.novartis.madt.util.PasswordEncUtil");

	Cipher ecipher;
	Cipher dcipher;

	PasswordEncUtil(SecretKey key) throws Exception {
		ecipher = Cipher.getInstance("AES");
		dcipher = Cipher.getInstance("AES");
		ecipher.init(Cipher.ENCRYPT_MODE, key);
		dcipher.init(Cipher.DECRYPT_MODE, key);
	}

	private String encrypt(String str) throws Exception {
		// Encode the string into bytes using utf-8
		byte[] utf8 = str.getBytes("UTF8");

		// Encrypt
		byte[] enc = ecipher.doFinal(utf8);

		// Encode bytes to base64 to get a string
		return Base64.encodeBase64String(enc);
	}

	/**
	 * This is to decrypt the password
	 * 
	 * @param str
	 * @return
	 * @throws Exception
	 */
	private String decrypt(String str) throws Exception {
		// Decode base64 to get bytes
		byte[] dec = Base64.decodeBase64(str);

		byte[] utf8 = dcipher.doFinal(dec);

		// Decode using utf-8
		return new String(utf8, "UTF8");
	}

	/**
	 * Main method for Testing
	 * 
	 * @param args
	 * @throws Exception
	 */
	public static void main(String args[]) throws Exception {
		String mode = "d";// args[0];
		String data = "XXXXXXX";// args[1];
		mode = "e";
		System.out.println(convert(data,mode));
	}

	/**
	 * This is used to encrpt and decrypt the String based on passing mode
	 * 
	 * @param mode
	 * @param data
	 * @return
	 */
	public static String convert(String mode, String data) {

		try {
			String k = ">Wh8Secr8!sThIs.";
			SecretKey key = new SecretKeySpec(k.getBytes(), "AES");
			PasswordEncUtil encrypter = new PasswordEncUtil(key);
			if (mode.equals("t")) {
				fLogger.info("inside convert:");
				String encrypted = encrypter.encrypt(data);
				String decrypted = encrypter.decrypt(encrypted);
				return decrypted;
			} else if (mode.equals("e")) {
				String encrypted = encrypter.encrypt(data);
				return encrypted;

			} else if (mode.equals("d")) {
				String decrypted = encrypter.decrypt(data);
				return decrypted;
			}
		} catch (Exception e) {
			fLogger.info(e.getMessage());
		}
		return "";
	}

}
