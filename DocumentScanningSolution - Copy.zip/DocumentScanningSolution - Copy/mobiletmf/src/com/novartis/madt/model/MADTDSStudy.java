package com.novartis.madt.model;

import java.util.Date;
import java.util.List;

/**
 * This model is used to store the folder data fetching from impact System
 * 
 * @author sankusr2
 *
 */
public class MADTDSStudy {

	private String createdDt;
	private String updDt;
	private String StudyId;
	private String country;
	private String siteId;
	private String CRAName;
	private String studyStatus;
	private List<String> CRAList;
	private String sspEndDt;
	
	public String getSspEndDt() {
		return sspEndDt;
	}

	public void setSspEndDt(String sspEndDt) {
		this.sspEndDt = sspEndDt;
	}

	public String getStudyStatus() {
		return studyStatus;
	}

	public void setStudyStatus(String studyStatus) {
		this.studyStatus = studyStatus;
	}

	
	
	public List<String> getCRAList() {
		return CRAList;
	}

	public void setCRAList(List<String> cRAList) {
		CRAList = cRAList;
	}

	public MADTDSStudy() {

	}

	/**
	 * 
	 * @return
	 */
	public String getStudyId() {
		return StudyId;
	}

	/**
	 * 
	 * @param studyId
	 */
	public void setStudyId(String studyId) {
		StudyId = studyId;
	}

	/**
	 * 
	 * @return
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * 
	 * @param country
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * Getting Site Id
	 * 
	 * @return
	 */
	public String getSiteId() {
		return siteId;
	}

	/**
	 * used for Site Id
	 * 
	 * @param siteId
	 */
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getCRAName() {
		return CRAName;
	}

	/**
	 * CRA User Id
	 * 
	 * @param cRAName
	 */
	public void setCRAName(String cRAName) {
		CRAName = cRAName;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	public String getUpdDt() {
		return updDt;
	}

	public void setUpdDt(String updDt) {
		this.updDt = updDt;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((StudyId == null) ? 0 : StudyId.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((siteId == null) ? 0 : siteId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MADTDSStudy other = (MADTDSStudy) obj;
		if (StudyId == null) {
			if (other.StudyId != null)
				return false;
		} else if (!StudyId.equals(other.StudyId))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (siteId == null) {
			if (other.siteId != null)
				return false;
		} else if (!siteId.equals(other.siteId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "MADTDSStudy [createdDt=" + createdDt + ", ESBUpdateDate=" + updDt + ", StudyId=" + StudyId + ", country="
				+ country + ", siteId=" + siteId + ", CRAName=" + CRAName + "]";
	}
}
