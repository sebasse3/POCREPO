package com.novartis.madt.exception;

import org.springframework.stereotype.Component;

@Component
public class DocumentScaningException extends Exception 
{
	
	public DocumentScaningException()
	{
		super();
	}
	public DocumentScaningException(String message){
		super(message);
		
	}
	
	public DocumentScaningException(String message,Throwable throwable){
		super(message,throwable);
		
	}
}
