package com.novartis.madt.repository;

import java.io.BufferedWriter;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.model.ListItem;
import com.novartis.madt.model.MADTDSStudy;

/**
 * @author medidsu1
 *
 */
public interface DocumentRepository {

	/**
	 * This method is used to downoload the file from site which is given
	 * 
	 * @param map
	 * @param fileName
	 * @param documentFolder
	 * @throws Exception
	 */
	public void download(Map<String, String> map, String fileName, String documentFolder) throws Exception;

	/**
	 * This method is used to checkout the file from site which is given in config
	 * file
	 * 
	 * @param map
	 * @param fileName
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	public int checkout(Map<String, String> map, String fileName, String documentFolder)
			throws DocumentScaningException;

	/**
	 * This method is used to discard the file from site which is given in config
	 * file
	 * 
	 * @param map
	 * @param fileName
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	public int discard(Map<String, String> map, String fileName, String documentFolder) throws DocumentScaningException;

	/**
	 * This method is used to checkin the file to site which is given in config file
	 * 
	 * @param map
	 * @param fileName
	 * @param documentFolder
	 * @param loger
	 * @throws DocumentScaningException
	 */
	public void checkIn(Map<String, String> map, String fileName, String documentFolder, String loger)
			throws DocumentScaningException;

	/**
	 * This method is used to upload the site which is given in config file
	 * 
	 * @param map
	 * @param fileName
	 * @param documentFolder
	 * @throws DocumentScaningException
	 */
	public String upload(Map<String, String> map, String fileName, String documentFolder, String pdfFolder,
			boolean bflag) throws DocumentScaningException;

	/**
	 * Release 2 - Changes implemented This method is used to update the site which
	 * is given in config file
	 * 
	 * @param map
	 * @param documentFolder
	 * @param hmpap
	 * @return
	 * @throws DocumentScaningException
	 */
	public int update(Map<String, String> map, String documentFolder, Map<String, String> hmpap)
			throws DocumentScaningException;

	/**
	 * This method is used to get the pending list from site which is given in
	 * config file
	 * 
	 * @param map
	 * @return
	 * @throws DocumentScaningException
	 */
	public List<String> getPendingList(Map<String, String> map) throws DocumentScaningException;

	/**
	 * This method is used to get metadata of the file from site
	 * 
	 * @param map
	 * @param id
	 * @return
	 * @throws DocumentScaningException
	 */
	public List<ListItem> documentList(Map<String, String> map, int id) throws DocumentScaningException;

	/**
	 * This method is used to get the id of file
	 * 
	 * @param map
	 * @param documentFolder
	 * @return
	 * @throws DocumentScaningException
	 */
	public String getID(Map<String, String> map, String documentFolder) throws DocumentScaningException;

	/**
	 * This method is used to get principal Id of the file
	 * 
	 * @param map
	 * @param documentFolder
	 * @param user
	 * @return
	 * @throws DocumentScaningException
	 */
	public String principalId(Map<String, String> map, String documentFolder, String user)
			throws DocumentScaningException;

	/**
	 * This method is used to create folder
	 * 
	 * @param map
	 * @param documentFolder
	 * @throws DocumentScaningException
	 */
	public void createFolder(Map<String, String> map, String documentFolder, MADTDSStudy studyObj, BufferedWriter bw)
			throws DocumentScaningException;

	/**
	 * This method is used to recreate permission on document
	 * 
	 * @param map
	 * @param itemId
	 * @param principalID
	 * @param documentFolder
	 * @param permission
	 * @throws DocumentScaningException
	 */
	public void recreatePermission(Map<String, String> map, String itemId, String principalID, String documentFolder,
			String permission, MADTDSStudy studyObj, BufferedWriter bw) throws DocumentScaningException;

	/**
	 * 
	 * @param map
	 * @param principalId
	 * @param itemId
	 * @param documentFolder
	 * @param permission
	 * @throws DocumentScaningException
	 */
	public void createFolderPermission(Map<String, String> map, String principalId, String itemId,
			String documentFolder, String permission, boolean remFlag, MADTDSStudy studyObj, BufferedWriter bw)
			throws DocumentScaningException;

	/**
	 * Releases #2 changes implemented- remove the access to all CRAs in case of
	 * completed and Cancelled trilas
	 * 
	 * @param map
	 * @param itemId
	 * @param principalID
	 * @param documentFolder
	 * @param studyObj
	 * @param bw
	 * @throws DocumentScaningException
	 */
	public void removePermission(Map<String, String> map, String itemId, String principalID, String documentFolder,
			MADTDSStudy studyObj, BufferedWriter bw) throws DocumentScaningException;

	/**
	 * 
	 * @param map
	 * @param documentFolder
	 * @param studyObj
	 * @param bw
	 * @return
	 * @throws DocumentScaningException
	 */
	public int createFolderList(Map<String, String> map, String documentFolder, MADTDSStudy studyObj, BufferedWriter bw)
			throws DocumentScaningException;

}
