package com.novartis.madt.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.novartis.madt.repository.DocumentRepository;
import com.novartis.madt.repositoryimpl.SharePointDocumntRepositoryImpl;
import com.novartis.madt.service.MADTDocumentService;
import com.novartis.madt.serviceimpl.MADTSharePointServiceImpl;
import com.novartis.madt.constants.JMADTConstants;
import com.novartis.madt.exception.DocumentScaningException;
import com.novartis.madt.model.JsonResponse;

@RestController
public class MADTSPController {
	
	public static String BASE_PATH = "/raid/apps/weblogic12/domains/mobiletmf.dss.intra/applications/madtapp/";
	   public static String POST = "POST";
	   public static String GET = "GET";
	
	@Value("${logLocation}")
	private String logLocation;
	@Autowired
	private MADTDocumentService documentService;
	Logger logger = Logger.getLogger(MADTSPController.class.getSimpleName());
	
	
	
	@PostConstruct
	 public void init() {
			InputStream is=null;
			try 
			{
				 is=new FileInputStream(logLocation);
				LogManager.getLogManager().readConfiguration(is);
			}

			catch (Exception e) {
				if(null !=is)
				{
					try {
						is.close();
					} catch (IOException e1) {
							
					}
				}
			}

		}
	

	@RequestMapping(value = "/documentConversion", produces = { "application/json" })
	public @ResponseBody JsonResponse initializeWorkflow(HttpServletRequest requsest,@RequestParam("filepath") String filePath,
			@RequestParam("fileName") String fileName) {
		Locale locale=requsest.getLocale();
		ResourceBundle messages = ResourceBundle.getBundle("messages", locale);
		String response = "request is  submitted";
		logger.info("Inialize workflow ");
		logger.info("FilePath :  "+filePath+"    :FileName :  "+fileName);
		String file=null;
		String documentpath=null;
		try {
			
			//getting space between fileName while url encodeing so replace with %20
			if(null != fileName && !"".equals(fileName))
			{
			 file=fileName.trim();
			 file=URLEncoder.encode(file,"UTF-8").replaceAll("\\+", "%20");
			}
			//getting space between fileName while url encodeing so replace with %20
			if(null != filePath &&!"".equals(filePath) )
			{
				documentpath=filePath.trim();
			    documentpath=URLEncoder.encode(filePath,"UTF-8").replaceAll("\\+", "%20");
			}
			if(!"".equals(filePath) && !"".equals(fileName))
			{
			//response = documentService.processDoucment(documentpath,file,messages);
			response = documentService.processDoucment("", documentpath, file, messages, 0);

			}
			else{
				logger.log(Level.SEVERE, "file Name and file path should not empty");
				response = "file Name and path should not be empty";
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "document scanning is failed" ,e);
			response = "FAILED";
		}
		logger.info("Status is  " + response);
		JsonResponse jsonResponse = new JsonResponse();
		jsonResponse.setResponse("request is submitted");

		return jsonResponse;
	}
	
	

}
