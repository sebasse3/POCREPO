package com.novartis.madt.model;

/**
 * @author medidsu1
 *
 */
public class JsonResponse {

	private String response;

	/**
	 * @return response
	 */
	public String getResponse() {
		return response;
	}

	/**
	 * @param response
	 */
	public void setResponse(String response) {
		this.response = response;
	}
	
}
