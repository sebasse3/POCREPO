package ae.daman.bcom.bpm.task;

import ae.daman.bcom.bpm.model.*;
import ae.daman.bcom.bpm.pagination.ConditionalPagination;
import ae.daman.bcom.bpm.pagination.Direction;
import ae.daman.bcom.bpm.util.BPMConstants;
import ae.daman.bcom.bpm.util.BPMProcessUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import oracle.bpel.services.bpm.common.IBPMContext;
import oracle.bpel.services.workflow.IWorkflowConstants;
import oracle.bpel.services.workflow.StaleObjectException;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.bpel.services.workflow.client.IWorkflowServiceClient;
import oracle.bpel.services.workflow.metadata.routingslip.model.*;
import oracle.bpel.services.workflow.query.ITaskQueryService;
import oracle.bpel.services.workflow.query.model.TaskCountType;
import oracle.bpel.services.workflow.repos.Column;
import oracle.bpel.services.workflow.repos.Ordering;
import oracle.bpel.services.workflow.repos.Predicate;
import oracle.bpel.services.workflow.repos.TableConstants;
import oracle.bpel.services.workflow.task.ITaskService;
import oracle.bpel.services.workflow.task.model.Task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import oracle.bpel.services.workflow.task.model.IdentityType;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.IOException;
import java.util.*;
import java.util.List;


@Component
@Slf4j
@Setter
public class TaskService {

	private static final Logger log = LoggerFactory.getLogger(TaskService.class);
    @Autowired
    private BPMProcessUtil bpmProcessUtil;

    public  Map<String, PoolsSummary> getPoolsList(String username) throws WorkflowException, IOException{
//        IBPMContext adminUserContext = BPMProcessUtil.getContext();

        log.info("taskPoolsList entry username1 :" +username);
        IBPMContext userContext = BPMProcessUtil.getContext(username);
        ITaskQueryService querySvc = BPMProcessUtil.getTaskQueryService();
        Predicate predicate = new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ, IWorkflowConstants.TASK_STATE_ASSIGNED);
//        predicate.addClause(Predicate.AND,TableConstants.WFTASK_ASSIGNEEGROUPS_COLUMN,Predicate.OP_EQ,IWorkflowConstants.PARTICIPANT_TYPE_GROUP);
        List<TaskCountType>  poolTasksUnassigned = querySvc.queryAggregatedTasks(userContext,TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE3_COLUMN,
                ITaskQueryService.AssignmentFilter.MY_AND_GROUP,null,predicate,true,false) ;

        log.info("Taskservice taskPoolsList  poolTasksUnassigned size :"+poolTasksUnassigned.size() );
        predicate = new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ, IWorkflowConstants.TASK_STATE_ASSIGNED);
//        predicate.addClause(Predicate.AND,TableConstants.WFTASK_ASSIGNEEUSERS_COLUMN,Predicate.OP_EQ,IWorkflowConstants.PARTICIPANT_TYPE_USER);
        List<TaskCountType>  poolTasksAssigned = querySvc.queryAggregatedTasks(userContext,TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE3_COLUMN,
                ITaskQueryService.AssignmentFilter.MY_AND_GROUP,null,predicate,true,false) ;

        log.info("Taskservice taskPoolsList  poolTasksAssigned size :"+poolTasksAssigned.size() );

        Map<String, PoolsSummary>  returnMap = new HashMap<>();
        poolTasksAssigned.forEach((TaskCountType task) -> {
            PoolsSummary poolsSummary  = new PoolsSummary();
            poolsSummary.setAssigned(task.getCount());
            poolsSummary.setValue(task.getValue());
            returnMap.put(task.getValue(),poolsSummary);

            });
        poolTasksUnassigned.forEach((TaskCountType task) -> {
            PoolsSummary poolsSummary = null;
            if(returnMap.containsKey(task.getValue())) {
                poolsSummary = returnMap.get(task.getValue());
            }else {
                poolsSummary = new PoolsSummary();
            }
            poolsSummary.setUnAssigned(task.getCount());
            poolsSummary.setValue(task.getValue());
                returnMap.put(task.getValue(), poolsSummary);


        });
        log.info("Taskservice taskPoolsList  returnMap size :"+returnMap.size() );
//        ITaskReportService queryReportSvc = BPMProcessUtil.getTaskReportService();
//        ReportInputType inputType = new ReportInputTypeImpl() ;
//        ReportInputParametersType reportInputParametersType = new ReportInputParametersTypeImpl();
//        reportInputParametersType.getReportInputParameter();
//        inputType.setReportName("UNATTENDED_TASKS_REPORT");
//        inputType.setReportInputParameters(reportInputParametersType);

            return returnMap;
        }


    public WorkflowPoolTasks getPoolsTaskList(String username) throws WorkflowException, IOException {
        log.info("getPoolsTaskList start");
        IBPMContext userContext = BPMProcessUtil.getContext(username);
        ITaskQueryService querySvc = BPMProcessUtil.getTaskQueryService();
        Predicate predicate = new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ, IWorkflowConstants.TASK_STATE_ASSIGNED);
//        predicate.addClause(Predicate.AND,TableConstants.WFTASK_ASSIGNEEGROUPS_COLUMN,Predicate.OP_EQ,IWorkflowConstants.PARTICIPANT_TYPE_GROUP);
       // IdentityType
        List<String> displayColumns = getDisplayColumns();

        log.info("BEGIN retrieving  tasks for getPoolsTaskList user : " + username);
        WorkflowPoolTasks userTasks = new WorkflowPoolTasks();

        userTasks.setTotalCount(querySvc.countTasks(userContext, ITaskQueryService.AssignmentFilter.MY_AND_GROUP_ALL, null, predicate));
        Ordering ordering = new Ordering(TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE3_COLUMN, true, true);
//        ordering.addClause(TableConstants.WFTASK_PRIORITY_COLUMN, true, true);

        List<Task> tasks = querySvc.queryTasks(userContext, getDisplayColumns(), getOptionalInfo(),
                ITaskQueryService.AssignmentFilter.MY_AND_GROUP_ALL, null, predicate, null, 0, 0);


        tasks.forEach((Task task) -> {

            userTasks.addTask(getWorkflowPoolsTask(task));

        });
        log.info("END retrieving getPoolsTaskList tasks for user : " + username);
        log.info("getPoolsTaskList end");
        return userTasks;
    }

    public WorkflowTasks getTasks(TaskListRequest request) throws WorkflowException, IOException {
        log.info("getTasks start");
//        IBPMContext adminUserContext = BPMProcessUtil.getContext();
        IBPMContext userContext = BPMProcessUtil.getContext(request.getUsername());
        ITaskQueryService querySvc = BPMProcessUtil.getTaskQueryService();
        Predicate predicate = getPredicate(request.getTaskStatusType());


        List<String> displayColumns = getDisplayColumns();

        Ordering ordering = getOrdering(request.getPagination());
        int startRow = (request.getPagination().getPage() - 1) * request.getPagination().getSize();
        int endRow = startRow + request.getPagination().getSize();

        log.info("BEGIN retrieving "+ request.getTaskStatusType() +" tasks for user : " + request.getUsername());
        WorkflowTasks userTasks = new WorkflowTasks();

        userTasks.setTotalCount(querySvc.countTasks(userContext, getAssignmentFilter(request.getTaskStatusType()), null, predicate));

        List<Task> tasks = querySvc.queryTasks(userContext, getDisplayColumns(), getOptionalInfo(),
                getAssignmentFilter(request.getTaskStatusType()), null, predicate, ordering, startRow, endRow);

        tasks.forEach((Task task) -> {
            // TODO - do we need to get the task details ? If yes, update the getWorkflowTask method and pass taskDtl
            try {
                Task taskDtl = querySvc.getTaskDetailsByNumber(userContext, task.getSystemAttributes().getTaskNumber());

                userTasks.addTask(getWorkflowTask(task,taskDtl));

            } catch (WorkflowException e) {
                e.printStackTrace();
            }

        });
        log.info("END retrieving TODO tasks for user : " + request.getUsername());
        log.info("getTasks end");
        return userTasks;
    }

    private WorkflowTask getWorkflowTask(Task task,Task taskDtl) {
        WorkflowTask wfTask = new WorkflowTask();
        wfTask.setTaskId(task.getSystemAttributes().getTaskId());
        wfTask.setTaskNumber(task.getSystemAttributes().getTaskNumber());
        wfTask.setReferenceNumber(task.getSystemMessageAttributes().getProtectedTextAttribute2());
        wfTask.setTaskType(task.getTitle());
        wfTask.setStartTime(task.getSystemAttributes().getAssignedDate().getTime());
        wfTask.setCustomerTat((long)(task.getSystemMessageAttributes().getProtectedNumberAttribute2()));
        wfTask.setActivityTat((long)task.getSystemMessageAttributes().getProtectedNumberAttribute1());
        wfTask.setPoolName(task.getSystemMessageAttributes().getProtectedTextAttribute3());
        wfTask.setTaskStatus(task.getSystemAttributes().getState());
        wfTask.setAssignedBy((task.getSystemAttributes().getUpdatedBy().getId().equalsIgnoreCase("weblogic") || task.getSystemAttributes().getUpdatedBy().getId().equalsIgnoreCase("workflowsystem") ? "System" : task.getSystemAttributes().getUpdatedBy().getId()));
        wfTask.setTeam(task.getSystemMessageAttributes().getProtectedTextAttribute5());
        wfTask.setReason(task.getSystemMessageAttributes().getProtectedTextAttribute4());
        wfTask.setPriority(Integer.toString(task.getPriority()));
//        wfTask.setPayload(taskDtl.getPayloadAsElement());

        java.util.List<IdentityType> taskAssignees = task.getSystemAttributes().getAssignees();
        wfTask.setAssignedTo(taskAssignees.get(0).getId());

        return wfTask;
    }
    private WorkflowPoolsTask getWorkflowPoolsTask(Task task) {
        WorkflowPoolsTask wfPoolsTask = new WorkflowPoolsTask();
        wfPoolsTask.setTaskId(task.getSystemAttributes().getTaskId());
        wfPoolsTask.setTaskNumber(task.getSystemAttributes().getTaskNumber());
        wfPoolsTask.setReferenceNumber(task.getSystemMessageAttributes().getProtectedTextAttribute2());
        wfPoolsTask.setStartTime(task.getSystemAttributes().getAssignedDate().getTime());
        wfPoolsTask.setCustomerTat((long)(task.getSystemMessageAttributes().getProtectedNumberAttribute2()));
        wfPoolsTask.setAssignBefore(task.getSystemAttributes().getState());
        wfPoolsTask.setAssignedBy(task.getSystemAttributes().getUpdatedBy().getId());
        java.util.List<IdentityType> taskAssignees = task.getSystemAttributes().getAssignees();
        wfPoolsTask.setAssignedTo(taskAssignees.get(0).getId());
        wfPoolsTask.setPoolName(task.getSystemMessageAttributes().getProtectedTextAttribute3());

        return wfPoolsTask;
    }

    public TaskUpdateResponse updateTask(TaskUpdateRequest request) throws WorkflowException,StaleObjectException, IOException {
        log.info("updateTask start");
        log.info("Update Task start "+ request.getTaskStatus() +"  for user : " + request.getUsername());
//        IBPMContext adminUserContext = BPMProcessUtil.getContext();
        IBPMContext userContext = BPMProcessUtil.getContext(request.getUsername());
        IWorkflowServiceClient client = BPMProcessUtil.getWorkflowServiceClient();
        ITaskQueryService itaskQueryService = client.getTaskQueryService();
        ITaskService taskService = client.getTaskService();
        Task task = itaskQueryService.getTaskDetailsByNumber(userContext,request.getTaskNumber());
//==================================================================================================================
        if(request.getTaskStatus().equalsIgnoreCase(BPMConstants.SEEK_APPROVAL)) {
//            task.getSystemMessageAttributes().setProtectedTextAttribute5("Raised for approval");
            log.info("updateTask state  to SEEK_APPROVAL");
            Element element = task.getPayloadAsElement();
            NodeList list = element.getElementsByTagName("assigneeGroup");
            if (list != null && list.getLength() > 0) {
                NodeList subList = list.item(0).getChildNodes();
                if (subList != null && subList.getLength() > 0) {
                    log.info("updateTask nodevalue2 :" + subList.item(0).getNodeValue());
                    subList.item(0).setNodeValue(request.getAppprover());
                    list.item(0).setNodeValue(request.getAppprover());
                    task.setPayloadAsElement(element);
                    log.info("element  nodeValue3: " + subList.item(0).getNodeValue());
                }
            }
            log.info("updateTask stask1 number : "+task.getSystemAttributes().getTaskNumber());
            taskService.updateTaskOutcome(userContext,task,request.getOutCome());
            log.info("updateTask state updated to SEEK_APPROVAL");

        }else if(request.getTaskStatus().equalsIgnoreCase(BPMConstants.SEEK_APPROVAL_SUBMITTED)){
            log.info("updateTask state  to SEEK_APPROVAL_SUBMITTED");
//            "APPROVE/REJECT/CLARIFICATION"
             taskService.updateTaskOutcome(userContext,task,request.getOutCome());
        }else{

            if (request.getTaskStatus().equalsIgnoreCase(BPMConstants.INFO_REQUESTED)) {
                task.getSystemMessageAttributes().setProtectedTextAttribute5("Raised for clarification");
                task.getSystemAttributes().setState(IWorkflowConstants.TASK_STATE_INFO_REQUESTED);
            }
            if (request.getTaskStatus().equalsIgnoreCase(BPMConstants.INFO_SUBMITTED)) {
                task.getSystemAttributes().setState(IWorkflowConstants.TASK_STATE_ASSIGNED);
            }
//            if (request.getTaskStatus().equalsIgnoreCase(BPMConstants.SEEK_APPROVAL)) {
//                task.getSystemMessageAttributes().setProtectedTextAttribute5("Raised for approval");
//                task.getSystemAttributes().setState(IWorkflowConstants.TASK_STATE_ALERTED);
//            }
//            if (request.getTaskStatus().equalsIgnoreCase(BPMConstants.ASSIGNED)) {
//                task.getSystemAttributes().setState(IWorkflowConstants.TASK_STATE_ASSIGNED);
//            }

            taskService.updateTask(userContext, task);
        }



        TaskUpdateResponse updateResponse = new TaskUpdateResponse();
        updateResponse.setUpdateResponseStatus("Success");
        log.info("Updating tasks for user : " + request.getUsername());
        log.info("updateTask ends");
        return updateResponse;

    }


    ITaskQueryService.AssignmentFilter getAssignmentFilter(TaskStatusType type){
        switch (type) {
            case ASSIGNED:
//                return ITaskQueryService.AssignmentFilter.MY;
                return ITaskQueryService.AssignmentFilter.MY_AND_GROUP_ALL;
            case PENDING_APPROVAL:
                return ITaskQueryService.AssignmentFilter.PREVIOUS;
            case PENDING_CLARIFICAITON:
                return ITaskQueryService.AssignmentFilter.MY_AND_GROUP;
        }
        return null;
    }

    Predicate getPredicate(TaskStatusType type) throws WorkflowException {
        switch (type){
            case ASSIGNED:
                return new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ, IWorkflowConstants.TASK_STATE_ASSIGNED);
            case PENDING_APPROVAL:
                return new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ, IWorkflowConstants.TASK_STATE_ALERTED);
            case PENDING_CLARIFICAITON:
                return new Predicate(TableConstants.WFTASK_STATE_COLUMN, Predicate.OP_EQ, IWorkflowConstants.TASK_STATE_INFO_REQUESTED);
        }//INFO_REQUESTED
        return null;
    }



    private List<String> getDisplayColumns() {
        //Display Column List

        List<String> displayColumns = new ArrayList<>();

        displayColumns.add(BPMConstants.TITLE);
        displayColumns.add(BPMConstants.TASKNUMBER);
        displayColumns.add(BPMConstants.PRIORITY);
        displayColumns.add(BPMConstants.ASSIGNEES);
        displayColumns.add(BPMConstants.OUTCOME);
        displayColumns.add(BPMConstants.STATE);
        displayColumns.add(BPMConstants.TASKID);
        displayColumns.add(BPMConstants.ACQUIREDBY_BY);
        displayColumns.add(BPMConstants.ASSIGNED_DATE);
        displayColumns.add(BPMConstants.CREATED_DATE);
        displayColumns.add(BPMConstants.UPDATED_BY);
        displayColumns.add(BPMConstants.START_DATE);
        displayColumns.add(BPMConstants.END_DATE);

        displayColumns.add(BPMConstants.REFERENCE_NUMBER);
        displayColumns.add(BPMConstants.POOL);
        displayColumns.add(BPMConstants.REASON);
        displayColumns.add(BPMConstants.TEAM);
        displayColumns.add(BPMConstants.ACTIVITYTAT);
        displayColumns.add(BPMConstants.CUSTOMERTAT);

        log.info(" getDisplayColumns done with displayColumns settings");

        return displayColumns;
    }

    private List getOptionalInfo() {
        //Optional Column
        List optionalInfo = new ArrayList();
        //optionalInfo.add("Comments");
        optionalInfo.add(ITaskQueryService.OptionalInfo.FLEXFIELD_MAPPINGS); //"Payload"
//        optionalInfo.add("Payload");
        return optionalInfo;
    }

    private Ordering getOrdering(ConditionalPagination criteria) throws WorkflowException {
        Ordering ordering = null;
        boolean isAscending = true;
        if (criteria.getDirection().equals(Direction.DESCENDING)) {
            isAscending = false;
        }
        if (criteria.getOrderBy() != null) {
            ordering = new Ordering(getTableColumn(criteria.getOrderBy()), isAscending, false);
            return ordering;
        }
        ordering = new Ordering(TableConstants.WFTASK_TITLE_COLUMN, isAscending, false);
        return ordering;
    }

    // TODO
    private Column getTableColumn(String columnName) {
        if(columnName.equalsIgnoreCase(BPMConstants.PRIORITY)){
            return TableConstants.WFTASK_PRIORITY_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.START_DATE)){
            return TableConstants.WFTASK_STARTDATE_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.REFERENCE_NUMBER)){
            return TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE2_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.POOL)){
            return TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE3_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.REASON)){
            return TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE4_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.TEAM)){
            return TableConstants.WFTASK_PROTECTEDTEXTATTRIBUTE5_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.ACTIVITYTAT)){
            return TableConstants.WFTASK_PROTECTEDNUMBERATTRIBUTE1_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.CUSTOMERTAT)){
            return TableConstants.WFTASK_PROTECTEDNUMBERATTRIBUTE2_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.STATUS)){
            return TableConstants.WFTASK_STATE_COLUMN;
        }
        if(columnName.equalsIgnoreCase(BPMConstants.TASKTYPE)){
            return TableConstants.WFTASK_TITLE_COLUMN;
        }
        if (columnName.equalsIgnoreCase(BPMConstants.ASSIGNED_BY))
        {
            return null;
        }
        return null;
    }
}
