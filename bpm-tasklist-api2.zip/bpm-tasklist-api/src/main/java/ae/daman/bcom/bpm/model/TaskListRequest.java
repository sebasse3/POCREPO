package ae.daman.bcom.bpm.model;

import ae.daman.bcom.bpm.pagination.ConditionalPagination;
import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;

@Data
@XmlRootElement
public class TaskListRequest {
    private String username;
    private ConditionalPagination pagination;
    private TaskStatusType taskStatusType;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public ConditionalPagination getPagination() {
		return pagination;
	}
	public void setPagination(ConditionalPagination pagination) {
		this.pagination = pagination;
	}
	public TaskStatusType getTaskStatusType() {
		return taskStatusType;
	}
	public void setTaskStatusType(TaskStatusType taskStatusType) {
		this.taskStatusType = taskStatusType;
	}
    
    
}


