package ae.daman.bcom.bpm.user;

import ae.daman.bcom.bpm.model.TaskReassignRequest;
import ae.daman.bcom.bpm.model.TaskReassignResponse;
import ae.daman.bcom.bpm.task.TaskService;
import ae.daman.bcom.bpm.util.BPMConstants;
import ae.daman.bcom.bpm.util.BPMProcessUtil;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import oracle.bpel.services.bpm.common.IBPMContext;
import oracle.bpel.services.workflow.IWorkflowConstants;
import oracle.bpel.services.workflow.StaleObjectException;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.bpel.services.workflow.client.IWorkflowServiceClient;
import oracle.bpel.services.workflow.query.ITaskQueryService;
import oracle.bpel.services.workflow.task.ITaskAssignee;
import oracle.bpel.services.workflow.task.ITaskService;
import oracle.bpel.services.workflow.task.impl.TaskAssignee;
import oracle.bpel.services.workflow.task.model.Task;
//import oracle.tip.pc.services.common.ServiceFactory;
import oracle.tip.pc.services.common.ServiceFactory;
import oracle.tip.pc.services.identity.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;

@Component
@Slf4j
@Setter
public class UserService {
	private static final Logger log = LoggerFactory.getLogger(UserService.class);
    public TaskReassignResponse reassignTask(TaskReassignRequest request) throws WorkflowException, StaleObjectException, IOException {
        log.info("reassignTask start");
        IBPMContext userContext = BPMProcessUtil.getContext();
//        IBPMContext userContext = BPMProcessUtil.getContext(request.getUsername());
        IWorkflowServiceClient client = BPMProcessUtil.getWorkflowServiceClient();
        ITaskQueryService itaskQueryService= client.getTaskQueryService();
        ITaskService taskService = client.getTaskService();
        Task task=itaskQueryService.getTaskDetailsByNumber(userContext,request.getTaskNumber());
        java.util.List<ITaskAssignee> taskAssignees=new ArrayList<>();

        if(request.getAssignmentType().equalsIgnoreCase(BPMConstants.ASSIGN)){
            ITaskAssignee iTaskAssignee=new TaskAssignee(request.getUsername(), false);
            taskAssignees.add(iTaskAssignee);
            taskService.reassignTask(userContext, task, taskAssignees);
        }if(request.getAssignmentType().equalsIgnoreCase(BPMConstants.REASSIGN)){
            ITaskAssignee iTaskAssignee=new TaskAssignee(request.getUsername(), false);
            taskAssignees.add(iTaskAssignee);
            taskService.reassignTask(userContext, task, taskAssignees);
        }if(request.getAssignmentType().equalsIgnoreCase(BPMConstants.RELEASETOPOOL)){
            ITaskAssignee iTaskAssignee=new TaskAssignee(request.getUsername(), true);
            taskAssignees.add(iTaskAssignee);
//            task.getSystemAttributes().setState(IWorkflowConstants.TASK_STATE_UNASSIGNED);
            taskService.reassignTask(userContext, task, taskAssignees);
        }

        TaskReassignResponse taskReassignResponse = new TaskReassignResponse();
        taskReassignResponse.setTaskReassignResponse("Success");
        log.info("reassignTask end");
        return taskReassignResponse;

    }
    public String getUserForTaskAssignment(String poolName) throws  BPMIdentityException {
        log.info("getUserForTaskAssignment start");
        String userId = "";

//        BPMIdentityService service2 = ServiceFactory.getIdentityServiceInstance();

        BPMAuthenticationService service = ServiceFactory.getIdentityServiceInstance("jazn.com");
        log.info("getUserForTaskAssignment getRealmName" + service.getRealmName());
//        ListsType.LogicalPeopleGroup getLogicalPeopleGroup(userContext, poolName)
//        java.util.List<ParticipantsType.Participant>	getLogicalPeopleGroupMembers(IBPMContext ctx, java.lang.String lpgId)
//        BPMAuthenticationService service = ServiceFactory.getAuthenticationServiceInstance("jazn.com");
//        BPMAuthenticationService service3 = ServiceFactory.getAuthenticationServiceInstance();
        log.info("getUserForTaskAssignment getRealmName" + service.getRealmName());
//        BPMAuthorizationService service2 = ServiceFactory.getAuthorizationServiceInstance("jazn.com");
//        log.info("getUserForTaskAssignment getRealmName" + service2.getRealmName());


//        java.util.List<BPMUser> bpmUsers =  service2.getParticipantsToGroup(poolName, true);
////        java.util.List<BPMUser> bpmUsers =  service.getRealmName().getParticipantsToGroup(poolName, true);
//        log.info("getUserForTaskAssignment start3 :" +bpmUsers.size());
//      if(bpmUsers != null && bpmUsers.size()>0){
//          for(int i=0; i<bpmUsers.size(); i++){
//              log.info("userId : " +bpmUsers.get(i));
//          }
//      }
//
//        BPMGroup groupName = service2.lookupGroup(poolName);
//        log.info("getTenantID : " +groupName.getTenantID());
//        log.info("getTenantName : " +groupName.getTenantName());

        return userId;
    }

}
