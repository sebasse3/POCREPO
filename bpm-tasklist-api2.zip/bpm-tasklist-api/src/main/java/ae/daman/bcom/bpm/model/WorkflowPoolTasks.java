package ae.daman.bcom.bpm.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

@Data
@XmlRootElement
public class WorkflowPoolTasks {


    private List<WorkflowPoolsTask> tasks = new ArrayList<>();

    private int totalCount;
    
    

    public List<WorkflowPoolsTask> getTasks() {
		return tasks;
	}



	public void setTasks(List<WorkflowPoolsTask> tasks) {
		this.tasks = tasks;
	}



	public int getTotalCount() {
		return totalCount;
	}



	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}



	public void addTask(WorkflowPoolsTask poolTask){
        this.tasks.add(poolTask);
    }

}