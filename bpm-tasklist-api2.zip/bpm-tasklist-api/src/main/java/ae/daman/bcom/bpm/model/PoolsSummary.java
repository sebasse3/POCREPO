package ae.daman.bcom.bpm.model;

import lombok.Data;

@Data
public class PoolsSummary {
    int assigned;
    int unAssigned;
    String value;
	public int getAssigned() {
		return assigned;
	}
	public void setAssigned(int assigned) {
		this.assigned = assigned;
	}
	public int getUnAssigned() {
		return unAssigned;
	}
	public void setUnAssigned(int unAssigned) {
		this.unAssigned = unAssigned;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
    
    
}
