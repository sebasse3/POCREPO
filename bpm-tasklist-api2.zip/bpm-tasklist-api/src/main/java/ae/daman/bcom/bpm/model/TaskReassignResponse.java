package ae.daman.bcom.bpm.model;
import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;


@Data
@XmlRootElement
public class TaskReassignResponse{

    private String taskReassignResponse;

	public String getTaskReassignResponse() {
		return taskReassignResponse;
	}

	public void setTaskReassignResponse(String taskReassignResponse) {
		this.taskReassignResponse = taskReassignResponse;
	}
    
    

}
