package ae.daman.bcom.bpm.config;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;

import javax.ws.rs.ApplicationPath;

@Configuration
@ApplicationPath("bpm")
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig(){
        packages("ae.daman.bcom.bpm.rest");
    }
}
