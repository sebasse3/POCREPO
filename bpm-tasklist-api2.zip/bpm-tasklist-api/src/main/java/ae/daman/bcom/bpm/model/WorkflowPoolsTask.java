package ae.daman.bcom.bpm.model;

import lombok.Data;
import org.w3c.dom.Element;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Data
@XmlRootElement

public class WorkflowPoolsTask {

    private String taskId;
    private Integer taskNumber;
    private String referenceNumber;
    private Date startTime;
    private long customerTat;
    private String assignBefore;
    private String assignedBy;
    private String assignedTo;
    private String poolName;
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public Integer getTaskNumber() {
		return taskNumber;
	}
	public void setTaskNumber(Integer taskNumber) {
		this.taskNumber = taskNumber;
	}
	public String getReferenceNumber() {
		return referenceNumber;
	}
	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public long getCustomerTat() {
		return customerTat;
	}
	public void setCustomerTat(long customerTat) {
		this.customerTat = customerTat;
	}
	public String getAssignBefore() {
		return assignBefore;
	}
	public void setAssignBefore(String assignBefore) {
		this.assignBefore = assignBefore;
	}
	public String getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(String assignedBy) {
		this.assignedBy = assignedBy;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
    
    

}
