package ae.daman.bcom.bpm.rest.api;

import ae.daman.bcom.bpm.model.*;
import oracle.bpel.services.workflow.StaleObjectException;
import oracle.bpel.services.workflow.WorkflowException;
import oracle.tip.pc.services.identity.BPMIdentityException;

import java.io.IOException;
import java.util.Map;

public interface BPMController {
    WorkflowTasks getTasks(TaskListRequest request) throws WorkflowException, IOException;
    TaskUpdateResponse updateTask(TaskUpdateRequest updateRequest) throws WorkflowException, StaleObjectException, IOException;
    TaskReassignResponse reassignTask(TaskReassignRequest reassignRequestRequest) throws WorkflowException, StaleObjectException, IOException;
    Map<String, PoolsSummary> getPoolsList(String username)throws WorkflowException, IOException;
    WorkflowPoolTasks getPoolsTaskList(String username) throws WorkflowException, IOException ;
//    Map<String, WorkflowPoolTasks>  getPoolsTaskList(String username) throws WorkflowException, IOException ;
    String getUserForTaskAssignment(String poolName) throws WorkflowException, BPMIdentityException , IOException ;
}
