package ae.daman.bcom.bpm.util;

import ae.daman.bcom.bpm.config.BPMProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
public class StaticContextInitializer {

    @Autowired
    private BPMProperties bpmProperties;

    @PostConstruct
    public void init(){
        BPMProcessUtil.setBPMProperties(bpmProperties);
    }
}
